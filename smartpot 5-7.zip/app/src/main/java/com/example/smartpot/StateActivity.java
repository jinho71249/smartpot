package com.example.smartpot;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.StringTokenizer;
import java.util.Timer;
import java.util.TimerTask;


public class StateActivity extends AppCompatActivity {
    private Spinner spinner;
    private ImageButton setting;
    private ImageButton menu;
    private String name;//식물이름
    private String data;//파이어베이스에서 값 가져올때 임시변수
    private TextView mode;
    private TextView ahumi;//습도
    private TextView temp;//온도
    private TextView lux;//조도
    private TextView shumi;//토양습도
    private TextView wLevel;//수위
    private int wlv;
    private String item[];
    private int num;
    private Intent foregroundServiceIntent;


    FirebaseDatabase database = FirebaseDatabase.getInstance();


    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.statelayout);
        final Db db=(Db)getApplication();
        initContent();
        initListener();

        name=db.getSelectedPot();

        readData();






        //Toast.makeText(getApplicationContext(), "만드는중", Toast.LENGTH_SHORT).show(); //테스트용
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (null != foregroundServiceIntent) {

        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==201) {
            if (resultCode == 200) {
                final Db db = (Db) getApplication();
                Toast.makeText(getApplicationContext(), "화분이 추가됐습니다.", Toast.LENGTH_SHORT).show(); //테스트용
                readData();

                final DatabaseReference myRef0 = database.getReference("admin/potAlarm");
                myRef0.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        String tmpcheck = dataSnapshot.getValue(String.class);
                        if(tmpcheck.equals("1")) {
                            myRef0.setValue("0");
                            //Toast.makeText(getApplicationContext(), "알림이 비활성화됩니다.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError error) {

                    }
                });
            }
        }
    }

    private void initContent(){ //xml과 동기화
        spinner=findViewById((R.id.spinner));
        setting=findViewById((R.id.setting));
        menu=findViewById((R.id.menu));
        mode=findViewById((R.id.mode));
        ahumi=findViewById((R.id.ahumi));
        temp=findViewById((R.id.temp));
        lux=findViewById((R.id.lux));
        shumi=findViewById((R.id.shumi));
        wLevel=findViewById((R.id.wLevel));
    }

    private void initListener(){//버튼이나 textview동작
        menu.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                final CharSequence[] menuitem={"화분 추가","화분 삭제", "전체 화분 제어모드", "식물인식"};
                AlertDialog.Builder menubox=new AlertDialog.Builder(StateActivity.this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert);
                menubox.setItems(menuitem, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(which==0){//화분 추가
                            Intent intent = new Intent(getApplicationContext(), BluetoothActivity.class);
                            startActivityForResult(intent, 201);
                        }
                        else if(which==2){//전체화분 제어모드
                            Intent intent = new Intent(getApplicationContext(), ManageActivity.class);
                            startActivity(intent);
                        }
                        else if(which==3){//식물 인식
                            Intent intent = new Intent(getApplicationContext(), SearchActivity.class);
                            startActivity(intent);
                        }
                        else if(which==1){//등록된 화분 삭제
                            final Db item=(Db)getApplication();
                            if(item.getPotNum()>1) {//등록된 화분이 1개를 초과하면
                                final CharSequence[] deleteitem = new CharSequence[item.getPotNum()];

                                for (int i = 0; i < item.getPotNum(); i++)
                                    deleteitem[i] = item.getNames(i); //선택된 이름을 지울이름 변수에 넣습니다.
                                AlertDialog.Builder deletebox = new AlertDialog.Builder(StateActivity.this,
                                        android.R.style.Theme_DeviceDefault_Light_Dialog_Alert);
                                deletebox.setItems(deleteitem, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        String delete = item.getNames(which);
                                        int i;//반복을 위한 변수
                                        String result = "";//지운 이름을 뺀 나머지 이름들이 들어갈 변수
                                        String tmp = Integer.toString(item.getPotNum() - 1);//화분갯수를 -1해줍니다.

                                        DatabaseReference myRef10 = database.getReference(delete);
                                        myRef10.setValue(null);//파이어베이스에서 지울화분의 데이터를 모조리 삭제합니다.

                                        DatabaseReference myRef11 = database.getReference("admin/potNum");
                                        myRef11.setValue(tmp);//-1한 화분 갯수를 파이어베이스에 저장

                                        for (i = 0; i < item.getPotNum(); i++) {
                                            if (i != which)//그 위치가 아닌 나머지 이름을 차래대로 붙여줍니다.
                                                result = result.concat(item.getNames(i) + "#");
                                            item.setPotNames(result);
                                        }

                                        DatabaseReference myRef12 = database.getReference("admin/potName");
                                        myRef12.setValue(item.getPotNames());//다 붙인 모든 화분이름을 파이어베이스에 저장합니다.
                                        item.setPotNum(Integer.parseInt(tmp)); //화분갯수 클라스 속성을 저장합니다
                                        item.setNamesnum(0);   //등록된 화분갯수 배열을 다시 처음부터

                                        StringTokenizer tokens = new StringTokenizer(item.getPotNames(), "#");
                                        while (tokens.hasMoreTokens()) {
                                            item.setNames(tokens.nextToken("#"));//토큰으로 분리해줍니다.
                                        }
                                        item.setSelectedPot(item.getNames(0));//각 화분의 이름을 다시 배열에 저장해줍니다
                                        readData(); // 마지막으로 다시 데이터를 읽어 옵니다.
                                        final DatabaseReference myRef0 = database.getReference("admin/potAlarm");
                                        myRef0.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(DataSnapshot dataSnapshot) {
                                                String tmpcheck = dataSnapshot.getValue(String.class);
                                                if(tmpcheck.equals("1")) {
                                                    myRef0.setValue("0");
                                                    //Toast.makeText(getApplicationContext(), "알림이 비활성화됩니다.", Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                            @Override
                                            public void onCancelled(DatabaseError error) {

                                            }
                                        });
                                    }
                                }).show();
                            }
                            else
                                Toast.makeText(getApplicationContext(), "등록된 화분이 1개미만으로 될수 없습니다.", Toast.LENGTH_SHORT).show();
                            //화분개수가 1인데 삭제하려는 경우
                        }
                    }
                }).show();
            }
        });

    }

    public void readData() { //상태값 파이어베이스에서 읽어오기
        final Db db=(Db)getApplication();
        name=db.getSelectedPot();
        num=db.getPotNum();
        item=new String[num];
        for(int i=0;i<num;i++){
            item[i]=db.getNames(i);
        }

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                db.setSelectedPot(parent.getItemAtPosition(position).toString());//선택된 이름 전역변수에 저장
                name=db.getSelectedPot();

                DatabaseReference myRef3 = database.getReference(name + "/potState/AHumi");//습도
                DatabaseReference myRef4 = database.getReference(name + "/potState/temp");//온도
                DatabaseReference myRef5 = database.getReference(name + "/potState/lux");//조도
                DatabaseReference myRef6 = database.getReference(name + "/potState/SHumi");//토양습도
                DatabaseReference myRef7 = database.getReference(name + "/potState/Wlevel");//수위
                DatabaseReference myRef8 = database.getReference(name + "/ControlSwitch");//수위

                setting.setOnClickListener(new View.OnClickListener(){//화분 제어모드로 이동
                    public void onClick(View v){
                        Intent intent=new Intent(getApplicationContext(), ControlActivity.class);
                        intent.putExtra("RC", "1");
                        intent.putExtra("potname", name);
                        startActivityForResult(intent, 103);
                    }
                });

                myRef3.addValueEventListener(new ValueEventListener() {//습도

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                        data = dataSnapshot.getValue(String.class);//값 가져오기

                        ahumi.setText(data);//textview에 값 설정하기
                        ahumi.setTextColor(Color.BLACK);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
                    }
                });


                myRef4.addValueEventListener(new ValueEventListener() {//온도

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        data = dataSnapshot.getValue(String.class);

                        temp.setText(data);
                        temp.setTextColor(Color.BLACK);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                    }
                });

                myRef5.addValueEventListener(new ValueEventListener() {//온도

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        data = dataSnapshot.getValue(String.class);

                        lux.setText(data);
                        lux.setTextColor(Color.BLACK);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                    }
                });


                myRef6.addValueEventListener(new ValueEventListener() {//토양습도

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        data = dataSnapshot.getValue(String.class);

                        shumi.setText(data);
                        shumi.setTextColor(Color.BLACK);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                    }
                });


                myRef7.addValueEventListener(new ValueEventListener() {//수위

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        data = dataSnapshot.getValue(String.class);
                        if(data!=null) {
                            wLevel.setText(data);
                            db.setWlv(data);
                            wlv = Integer.parseInt(db.getWlv());
                            if (wlv <= 30)
                                wLevel.setTextColor(Color.RED);
                            else
                                wLevel.setTextColor(Color.BLACK);
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError error) {
                    }
                });


                myRef8.addValueEventListener(new ValueEventListener() {//토양습도

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        data = dataSnapshot.getValue(String.class);
                        if(data!=null) {
                            if (data.equals("0"))
                                mode.setText("수동모드");
                            else if (data.equals("1"))
                                mode.setText("자동모드");
                            else
                                mode.setText("unknown");//오류가 났을때
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {//화분이 등록안돼 있을 경우에만 작동
                //이런 경우 없음
            }
        });

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(StateActivity.this, android.R.layout.simple_spinner_item, item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);//스피너 적용
        spinner.setAdapter(adapter);


    }//readdata종료

    protected void onDestory(){

        super.onDestroy();
    }



}
