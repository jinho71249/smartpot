package com.example.smartpot;


import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.CombinedChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LegendEntry;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.CombinedData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.StringTokenizer;


public class ReceiveDaily extends BroadcastReceiver {
    private String data;
    protected String ahumi="";
    protected String temp="";
    protected String lux="";
    protected String shumi="";
    protected String date="";
    protected String concatdata="#";

    FirebaseDatabase database = FirebaseDatabase.getInstance();



    public void onReceive(Context context, Intent intent) {
        SimpleDateFormat format=new SimpleDateFormat("MM-dd");
        Calendar time=Calendar.getInstance();
        date=format.format(time.getTime());

        DatabaseReference myRef1 = database.getReference("1/potState/AHumi");//습도
        DatabaseReference myRef2 = database.getReference("1/potState/temp");//온도
        DatabaseReference myRef3 = database.getReference("1/potState/SHumi");//토양습도
        DatabaseReference myRef4 = database.getReference("1/potState/lux");//조도

        myRef1.addListenerForSingleValueEvent(new ValueEventListener() {//습도
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                ahumi=data;
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        myRef2.addListenerForSingleValueEvent(new ValueEventListener() {//온도
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                temp=data;
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });
        myRef3.addListenerForSingleValueEvent(new ValueEventListener() {//토양습도
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                shumi=data;
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });
        myRef4.addListenerForSingleValueEvent(new ValueEventListener() {//조도
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                lux=data;
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });
        waitdata();
    }

    protected void waitdata(){

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if(ahumi.equals("")||temp.equals("")||shumi.equals("")||lux.equals("")){
                    waitdata();
                }
                else {
                    concatdata=concatdata.concat(ahumi+"#");
                    concatdata=concatdata.concat(temp+"#");
                    concatdata=concatdata.concat(shumi+"#");
                    concatdata=concatdata.concat(lux+"#");

                    DatabaseReference myRef10 = database.getReference(date);
                    myRef10.setValue(concatdata);

                }

            }
        }, 1000);
    }






}
