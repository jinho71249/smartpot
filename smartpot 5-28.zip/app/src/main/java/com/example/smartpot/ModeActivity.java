package com.example.smartpot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ModeActivity extends AppCompatActivity {
    private TextView selectedName;
    private ImageView modeImg;
    private ImageView manualBtn;
    private ImageView autoBtn;
    private ImageView backBtn;
    private ImageView saveBtn;
    private EditText autoWPercent;
    private EditText autoWContent;
    private EditText lightTmp;
    private EditText lightLux;
    private Spinner auto_spinner;
    protected int selectedNum;
    private String data;
    protected String selectedID;
    protected String selected;
    protected String modecheck;
    private String autoWpercent;
    private String autoWcontent;
    private String lighttmp;
    private String lightlux;
    private String[] plantData={"사용자 설정", "개운죽","금전수", "꽃베고니아", "나한송", "레티지아",
            "무늬산호수", "뮤렌베키아","사랑초","산호수", "시클라멘", "율마", "클레마티스", "포인세티아", "협죽도"};
    private String[][] autoData={{},{"30","100","13","200"},{"30","100","13","700"},{"50","100","13","1400"},{"30","100","5","700"},
            {"10","100","5","600"},{"30","100","0","700"}, {"30","100","10","200"}, {"30","100","10","700"}, {"30","100","5","200"},
            {"30","100","7","700"},{"30","100","10","1400"},{"30","100","0","1400"},{"30","100","13","1400"},{"30","100","7","1400"}};

    FirebaseDatabase database = FirebaseDatabase.getInstance();


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.modelayout);
        final Db db=(Db)getApplication();

        Intent intent=getIntent();
        selectedNum=intent.getIntExtra("selectedNum", -1);

        initContent();
        initListener();

    }

    private void initContent(){
        modeImg=findViewById(R.id.modeImg);
        selectedName=findViewById(R.id.selectedName);
        autoWPercent=findViewById(R.id.autoWPercent);
        autoWContent=findViewById(R.id.autoWContent);
        auto_spinner=findViewById(R.id.auto_spinner);
        lightTmp=findViewById(R.id.lightTmp);
        lightLux=findViewById(R.id.lightLux);
        manualBtn=findViewById(R.id.manualBtn);
        autoBtn=findViewById(R.id.autoBtn);
        backBtn=findViewById(R.id.backBtn);
        saveBtn=findViewById(R.id.saveBtn);
    }

    private void initListener(){
        final Db db=(Db)getApplication();
        selectedID =db.getSelectedPot();
        selected =db.getNames(selectedNum);

        selectedName.setText(selected);

        DatabaseReference myRef10 = database.getReference(selectedID + "/ControlSwitch");//자,수동모드
        myRef10.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                modecheck=data;
                if(modecheck==null){//화분을 모두 삭제 됐을때 오류 없애기
                    finish();
                }
                else if(modecheck.equals("0")){//수동manual
                    modeImg.setBackgroundResource(R.mipmap.mode_manual);
                    manualBtn.setBackgroundResource(R.mipmap.manual2);
                    autoBtn.setBackgroundResource(R.mipmap.auto1);
                }
                else {//자동auto
                    modeImg.setBackgroundResource(R.mipmap.mode_auto);
                    manualBtn.setBackgroundResource(R.mipmap.manual1);
                    autoBtn.setBackgroundResource(R.mipmap.auto2);
                }
            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        auto_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position!=0) {
                    autoWPercent.setText(autoData[position][0]);
                    autoWContent.setText(autoData[position][1]);
                    lightTmp.setText(autoData[position][2]);
                    lightLux.setText(autoData[position][3]);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //이런 경우 없음
            }
        });


        ArrayAdapter<String> adapter=new ArrayAdapter<String>(ModeActivity.this, android.R.layout.simple_spinner_item, plantData);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);//스피너 적용
        auto_spinner.setAdapter(adapter);



        manualBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference myRef1 = database.getReference(selectedID + "/ControlSwitch");//자,수동모드
                if(modecheck.equals("1")){//자동일때
                    modecheck="0";//수동으로
                    myRef1.setValue("0");//파이어베이스에도
                }


            }
        });//수동 버튼

        autoBtn.setOnClickListener(new View.OnClickListener() {//위와 같은 동작
            @Override
            public void onClick(View v) {
                DatabaseReference myRef1 = database.getReference(selectedID + "/ControlSwitch");//자,수동모드
                if(modecheck.equals("0")){//수동일때
                    modecheck="1";//자동으로
                    myRef1.setValue("1");//파이어베이스에도
                }

            }
        });//자동 버튼

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                autoWpercent=autoWContent.getText().toString();
                autoWcontent=autoWContent.getText().toString();
                lighttmp=lightTmp.getText().toString();
                lightlux=lightLux.getText().toString();

                DatabaseReference myRef1 = database.getReference(selectedID +"/autoControl/autoWpercent"); //파이어베이스로 값전달
                myRef1.setValue(autoWpercent);
                DatabaseReference myRef2 = database.getReference(selectedID +"/autoControl/autoWcontent"); //파이어베이스로 값전달
                myRef2.setValue(autoWcontent);
                DatabaseReference myRef3 = database.getReference(selectedID +"/autoControl/lightTmp"); //파이어베이스로 값전달
                myRef3.setValue(lighttmp);
                DatabaseReference myRef4 = database.getReference(selectedID +"/autoControl/lightLux"); //파이어베이스로 값전달
                myRef4.setValue(lightlux);

                finish();

            }
        });//back버튼

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });//back버튼
    }


}
