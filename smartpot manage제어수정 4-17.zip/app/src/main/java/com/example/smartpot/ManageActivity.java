package com.example.smartpot;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class ManageActivity extends AppCompatActivity {

    private ImageButton backBtn;
    private ListView listView;
    private ListaAdapter adapter;

    private String [] item;
    private String [] checks;
    private String potnames;
    private int num;
    private String tmp;
    String tm;

    int i;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference [] myRef;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.managelayout);

        readdata();



        backBtn=findViewById(R.id.backBtn);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//뒤로가기 버튼
                finish();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==120){
            if(resultCode==121) {
                readdata();
            }
        }
    }

    public void readdata(){

        adapter=new ListaAdapter();
        listView=(ListView) findViewById(R.id.listview);
        listView.setAdapter(adapter);

        final Db data=(Db)getApplication();
        data.setChecknum(0);
        num=data.getPotNum();
        item=new String[num];
        checks=new String[num];

        for(int i=0;i<num;i++){
            item[i]=data.getNames(i);
        }

        myRef=new DatabaseReference[num];

        for(i=0;i<num;i++) {//화분 개수만큼 제어모드 정보 가져오기
            myRef[i]=database.getReference(item[i]+"/ControlSwitch");
            myRef[i].addValueEventListener(new ValueEventListener() {

                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    tmp = dataSnapshot.getValue(String.class);
                    data.setChecks(tmp);
                    adapter.notifyDataSetChanged();
                }
                @Override
                public void onCancelled(DatabaseError error) {

                }
            });

        }

        final Handler handler=new Handler();//정보를 가져오는데 약1초정도 딜레이가 있어 1.5초후에 리스트에 등록
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                for (i = 0; i < num; i++) {//정보를 가져와
                    if(data.getChecks(i).equals("0"))
                        tm="수동모드";
                    else if(data.getChecks(i).equals("1"))
                        tm="자동모드";
                    else
                        tm="unknown";

                    adapter.addItem(item[i], R.mipmap.setting, tm);

                }
                adapter.notifyDataSetChanged();//리스트가 갱신된 것을 알림

            }
        }, 1500);

        //Toast.makeText(getApplicationContext(), data.getCheck(0), Toast.LENGTH_SHORT).show(); //테스트용
    }


    class ListaAdapter extends BaseAdapter{ //리스트 클라스
        private ImageView iconView;//설정 이미지
        private TextView potName1; //화분 이름
        private TextView mode1;   //제어모드
        ArrayList<Db> dbList=new ArrayList<Db>(); //각 화분의 정보가 들어있는 배열

        public ListaAdapter(){ }

        public void addItem(String name, int icon, String mode){//배열에 리스트추가 하기
            Db db=new Db();
            db.setName(name);
            db.setImage(icon);
            db.setMode(mode);

            dbList.add(db);
        }

        public View getView(int position, View cView, ViewGroup parent){//리스트뷰에 들어갈 리스트 설정
            final int pos=position; //리스트 번호
            final Context context=parent.getContext();

            if(cView==null){
                LayoutInflater inflater=(LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
                cView=inflater.inflate(R.layout.listview, parent, false);
            }
            potName1=(TextView)cView.findViewById(R.id.potName1);//화분 이름
            iconView=(ImageView)cView.findViewById(R.id.image1);//설정 이미지
            mode1=(TextView)cView.findViewById(R.id.mode1); //제어모드

            iconView.setOnClickListener(new View.OnClickListener(){
                public void onClick(View v){//설정이미지에 클릭 이벤트추가
                    Intent intent=new Intent(getApplicationContext(), ControlActivity.class);//설정 창으로 이동
                    intent.putExtra("potnum", pos);
                    intent.putExtra("RC", "0");
                    startActivityForResult(intent, 120);
                }
            });

            Db db=dbList.get(position);//리스트 번호 가져오기

            potName1.setText(db.getName());//뷰에 정보 넣기
            mode1.setText(db.getMode());
            iconView.setImageResource(db.getImage());

            return cView;
        }

        public int getCount(){
            return dbList.size();
        }

        public Object getItem(int i){
            return dbList.get(i);
        }

        public long getItemId(int position){
            return position;
        }

    }

}
