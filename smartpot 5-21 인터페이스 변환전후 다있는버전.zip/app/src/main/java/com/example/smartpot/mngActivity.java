package com.example.smartpot;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class mngActivity extends AppCompatActivity {
    private PieChart wpieChart;
    private TextView selectedName;
    private ImageButton rightBtn;
    private ImageButton leftBtn;
    private ImageButton mngBtn;
    private ImageButton waterBtn;
    private ImageButton lightBtn;
    private ImageButton backBtn;
    protected String modecheck;
    protected String lightcheck;
    protected String item[];
    protected String name;
    protected int wlv;
    protected int num;
    protected int selectedNum;
    private String data;
    protected int ahumi;
    static int PERCENT=100;


    FirebaseDatabase database = FirebaseDatabase.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mnglayout);
        initContent();
        initListener();
        setPieChart();
        readdata();


    }
    private void initContent(){
        wpieChart=findViewById(R.id.piechart);
        selectedName=findViewById(R.id.selectedName);
        rightBtn=findViewById(R.id.rightBtn);
        leftBtn=findViewById(R.id.leftBtn);
        mngBtn=findViewById(R.id.mngBtn);
        waterBtn=findViewById(R.id.waterBtn);
        lightBtn=findViewById(R.id.lightBtn);
        backBtn=findViewById(R.id.backBtn);

        //waterBtn.setBackgroundResource(R.mipmap.wateringbtn);



    }

    private void initListener(){
        final Db db=(Db)getApplication();
        Intent intent=getIntent();
        wlv=intent.getIntExtra("wlv", 0);
        //Toast.makeText(getApplicationContext(), Integer.toString(wlv), Toast.LENGTH_SHORT).show(); //테스트용

        name=db.getSelectedPot();
        num=db.getPotNum();
        item=new String[num];
        for(int i=0;i<num;i++){
            item[i]=db.getNames(i);
        }
        for(int i=0;i<num;i++){
            if(name.equals(item[i]))
                selectedNum=i;
        }

        selectedName.setText(name);

        rightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedNum++;
                if(selectedNum==num)
                    selectedNum=0;
                name=item[selectedNum];
                db.setSelectedPot(name);
                selectedName.setText(name);
                readdata();

            }
        });//다음 화분 버튼

        leftBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(selectedNum==0)
                    selectedNum=num-1;
                else
                    selectedNum--;
                name=item[selectedNum];
                db.setSelectedPot(name);
                selectedName.setText(name);
                readdata();

            }
        });//이전 화분 버튼

        lightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), LightActivity.class);//조명 설성으로 이동
                startActivity(intent);
            }
        });//조명버튼

        waterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), WaterActivity.class);//수분공급 설성으로 이동
                //Toast.makeText(getApplicationContext(), Integer.toString(ahumi), Toast.LENGTH_SHORT).show();
                intent.putExtra("ahumi", ahumi);
                startActivity(intent);
            }
        });//수분공급 버튼

        mngBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), ModeActivity.class);//모드 설성으로 이동
                startActivity(intent);
            }
        });//모드설정 버튼

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });//back버튼


    }

    private void setPieChart(){
        ArrayList chartContent=new ArrayList();
        chartContent.add(new PieEntry(wlv, "남은 물"));
        chartContent.add(new PieEntry(PERCENT-wlv, "빈 공간"));

        PieDataSet dataSet=new PieDataSet(chartContent, null);
        PieData data=new PieData(dataSet);

        wpieChart.setData(data);
        wpieChart.setDrawCenterText(true);
        wpieChart.setCenterText("test");
        wpieChart.setDescription(null);
        wpieChart.setTransparentCircleRadius(0);//그래프 안쪽 입체감 0
        wpieChart.setCenterTextSize(40);

        Legend legend=wpieChart.getLegend();
        legend.setEnabled(false);

        dataSet.setColors(Color.rgb(77,145,227), Color.GRAY);

    }

    private void readdata(){
        DatabaseReference myRef1 = database.getReference(name + "/potState/AHumi");//토양습도
        myRef1.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                ahumi=Integer.parseInt(data);

            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        DatabaseReference myRef2 = database.getReference(name + "/potState/Wlevel");//수위
        myRef2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                wlv=Integer.parseInt(data);
                setPieChart();
                wpieChart.notifyDataSetChanged();
                wpieChart.invalidate();

            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        DatabaseReference myRef3 = database.getReference(name + "/manualControl/lampSwitch");//조명 스위치
        myRef3.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                if(data!=null) {
                    modecheck=data;
                    if (modecheck.equals("0"))
                        lightBtn.setBackgroundResource(R.mipmap.lightbtn_off);
                    else
                        lightBtn.setBackgroundResource(R.mipmap.lightbtn_on);
                }

            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        DatabaseReference myRef4 = database.getReference(name + "/ControlSwitch");//자,수동모드
        myRef4.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                if(data!=null) {
                    lightcheck=data;
                    if (lightcheck.equals("0")) {
                        mngBtn.setBackgroundResource(R.mipmap.modebtn_manual);
                        waterBtn.setEnabled(true);
                        lightBtn.setEnabled(true);
                    }
                    else {
                        mngBtn.setBackgroundResource(R.mipmap.modebtn_auto);
                        waterBtn.setEnabled(false);
                        lightBtn.setEnabled(false);
                    }
                }

            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });
    }//readdata

}

