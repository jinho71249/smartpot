package com.example.smartpot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ModeActivity extends AppCompatActivity {
    private TextView selectedName;
    private ImageView modeImg;
    private ImageView manualBtn;
    private ImageView autoBtn;
    private ImageView backBtn;
    private ImageView saveBtn;
    private EditText autoWPercent;
    private EditText autoWContent;
    private EditText lightTmp;
    private EditText lightLux;
    private String data;
    protected String name;
    protected String modecheck;
    private String autoWpercent;
    private String autoWcontent;
    private String lighttmp;
    private String lightlux;

    FirebaseDatabase database = FirebaseDatabase.getInstance();


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.modelayout);
        final Db db=(Db)getApplication();

        initContent();
        initListener();

    }

    private void initContent(){
        modeImg=findViewById(R.id.modeImg);
        selectedName=findViewById(R.id.selectedName);
        autoWPercent=findViewById(R.id.autoWPercent);
        autoWContent=findViewById(R.id.autoWContent);
        lightTmp=findViewById(R.id.lightTmp);
        lightLux=findViewById(R.id.lightLux);
        manualBtn=findViewById(R.id.manualBtn);
        autoBtn=findViewById(R.id.autoBtn);
        backBtn=findViewById(R.id.backBtn);
        saveBtn=findViewById(R.id.saveBtn);
    }

    private void initListener(){
        final Db db=(Db)getApplication();
        name=db.getSelectedPot();

        selectedName.setText(name);

        DatabaseReference myRef10 = database.getReference(name + "/ControlSwitch");//자,수동모드
        myRef10.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                modecheck=data;
                if(modecheck.equals("0")){//수동manual
                    modeImg.setBackgroundResource(R.mipmap.mode_manual);
                    manualBtn.setBackgroundResource(R.mipmap.manual2);
                    autoBtn.setBackgroundResource(R.mipmap.auto1);
                }
                else {//자동auto
                    modeImg.setBackgroundResource(R.mipmap.mode_auto);
                    manualBtn.setBackgroundResource(R.mipmap.manual1);
                    autoBtn.setBackgroundResource(R.mipmap.auto2);
                }
            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });



        manualBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference myRef1 = database.getReference(name + "/ControlSwitch");//자,수동모드
                if(modecheck.equals("1")){//자동일때
                    modecheck="0";//수동으로
                    myRef1.setValue("0");//파이어베이스에도
                }
                else{//수동일때 반대로
                    modecheck="1";
                    myRef1.setValue("1");
                }

            }
        });//on버튼

        autoBtn.setOnClickListener(new View.OnClickListener() {//위와 같은 동작
            @Override
            public void onClick(View v) {
                DatabaseReference myRef1 = database.getReference(name + "/ControlSwitch");//자,수동모드
                if(modecheck.equals("1")){//자동일때
                    modecheck="0";//수동으로
                    myRef1.setValue("0");//파이어베이스에도
                }
                else{//수동일때 반대로
                    modecheck="1";
                    myRef1.setValue("1");
                }

            }
        });//off버튼

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                autoWpercent=autoWContent.getText().toString();
                autoWcontent=autoWContent.getText().toString();
                lighttmp=lightTmp.getText().toString();
                lightlux=lightLux.getText().toString();

                DatabaseReference myRef1 = database.getReference(name+"/autoControl/autoWpercent"); //파이어베이스로 값전달
                myRef1.setValue(autoWpercent);
                DatabaseReference myRef2 = database.getReference(name+"/autoControl/autoWcontent"); //파이어베이스로 값전달
                myRef2.setValue(autoWcontent);
                DatabaseReference myRef3 = database.getReference(name+"/autoControl/lightTmp"); //파이어베이스로 값전달
                myRef3.setValue(lighttmp);
                DatabaseReference myRef4 = database.getReference(name+"/autoControl/lightLux"); //파이어베이스로 값전달
                myRef4.setValue(lightlux);

                finish();

            }
        });//back버튼

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });//back버튼
    }


}
