package com.example.smartpot;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListPopupWindow;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Field;
import java.util.StringTokenizer;

public class AutoActivity extends AppCompatActivity {
    private Spinner auto_spinner;
    private ImageButton saveBtn;
    private ImageButton backBtn;
    private EditText autoWpercent;
    private EditText autoWcontent;
    private EditText lightLux;
    private EditText lightTmp;
    private String autoWPercent;
    private String autoWContent;
    private String lighttmp;
    private String lightlux;
    private String data;
    private int num;
    private String potnames;
    private String[] item;
    private String name;
    private String[] plantData={"사용자 설정", "개운죽","금전수", "꽃베고니아", "나한송", "레티지아",
    "무늬산호수", "뮤렌베키아","사랑초","산호수", "시클라멘", "율마", "클레마티스", "포인세티아", "협죽도"};

    FirebaseDatabase database = FirebaseDatabase.getInstance();


    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.autolayout);

        Intent intent=getIntent();
        name=intent.getStringExtra("name");

        initContent();
        initListener();
    }

    private void initContent(){
        auto_spinner=findViewById(R.id.auto_spinner);
        saveBtn=findViewById(R.id.saveBtn);
        backBtn=findViewById(R.id.backBtn);
        autoWpercent=findViewById(R.id.autoWpercent);
        autoWcontent=findViewById(R.id.autoWcontent);
        lightTmp=findViewById(R.id.lightTmp);
        lightLux=findViewById(R.id.lightLux);

    }

    private void initListener(){
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent out = new Intent();
                setResult(RESULT_CANCELED, out);
                finish();
            }
        });

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                autoWPercent=autoWpercent.getText().toString();
                autoWContent=autoWcontent.getText().toString();
                lighttmp=lightTmp.getText().toString();
                lightlux=lightTmp.getText().toString();

                DatabaseReference myRef1 = database.getReference(name+"/autoControl/autoWpercent"); //파이어베이스로 값전달
                myRef1.setValue(autoWPercent);
                DatabaseReference myRef2 = database.getReference(name+"/autoControl/autoWcontent"); //파이어베이스로 값전달
                myRef2.setValue(autoWContent);
                DatabaseReference myRef3 = database.getReference(name+"/autoControl/lightTmp"); //파이어베이스로 값전달
                myRef3.setValue(lighttmp);
                DatabaseReference myRef4 = database.getReference(name+"/autoControl/lightLux"); //파이어베이스로 값전달
                myRef3.setValue(lightlux);

                finish();
            }
        });//저장버튼


        auto_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 1:
                        autoWpercent.setText("30");
                        autoWcontent.setText("100");
                        lightTmp.setText("13");
                        lightLux.setText("200");
                        break;
                    case 2:
                        autoWpercent.setText("30");
                        autoWcontent.setText("100");
                        lightTmp.setText("13");
                        lightLux.setText("700");
                        break;
                    case 3:
                        autoWpercent.setText("50");
                        autoWcontent.setText("100");
                        lightTmp.setText("13");
                        lightLux.setText("1400");
                        break;
                    case 4:
                        autoWpercent.setText("30");
                        autoWcontent.setText("100");
                        lightTmp.setText("5");
                        lightLux.setText("700");
                        break;
                    case 5:
                        autoWpercent.setText("10");
                        autoWcontent.setText("100");
                        lightTmp.setText("5");
                        lightLux.setText("600");
                        break;
                    case 6:
                        autoWpercent.setText("30");
                        autoWcontent.setText("100");
                        lightTmp.setText("0");
                        lightLux.setText("700");
                        break;

                    case 7:
                        autoWpercent.setText("30");
                        autoWcontent.setText("100");
                        lightTmp.setText("10");
                        lightLux.setText("200");
                        break;

                    case 8:
                        autoWpercent.setText("30");
                        autoWcontent.setText("100");
                        lightTmp.setText("10");
                        lightLux.setText("700");
                        break;

                    case 9:
                        autoWpercent.setText("30");
                        autoWcontent.setText("100");
                        lightTmp.setText("5");
                        lightLux.setText("200");
                        break;

                    case 10:
                        autoWpercent.setText("30");
                        autoWcontent.setText("100");
                        lightTmp.setText("7");
                        lightLux.setText("700");
                        break;

                    case 11:
                        autoWpercent.setText("30");
                        autoWcontent.setText("100");
                        lightTmp.setText("10");
                        lightLux.setText("1400");
                        break;

                    case 12:
                        autoWpercent.setText("30");
                        autoWcontent.setText("100");
                        lightTmp.setText("0");
                        lightLux.setText("1400");
                        break;

                    case 13:
                        autoWpercent.setText("30");
                        autoWcontent.setText("100");
                        lightTmp.setText("13");
                        lightLux.setText("1400");
                        break;

                    case 14:
                        autoWpercent.setText("30");
                        autoWcontent.setText("100");
                        lightTmp.setText("7");
                        lightLux.setText("700");
                        break;

                        default:
                            break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //이런 경우 없음
            }
        });


        ArrayAdapter<String> adapter=new ArrayAdapter<String>(AutoActivity.this, android.R.layout.simple_spinner_item, plantData);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);//스피너 적용
        auto_spinner.setAdapter(adapter);


        DatabaseReference myRef1 = database.getReference(name+"/autoControl/autoWpercent");//습도
        myRef1.addListenerForSingleValueEvent(new ValueEventListener() {//습도

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                data = dataSnapshot.getValue(String.class);//값 가져오기

                autoWpercent.setText(data);//textview에 값 설정하기
            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        DatabaseReference myRef2 = database.getReference(name+"/autoControl/autoWcontent");//습도
        myRef2.addListenerForSingleValueEvent(new ValueEventListener() {//습도

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                data = dataSnapshot.getValue(String.class);//값 가져오기

                autoWcontent.setText(data);//textview에 값 설정하기
            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        DatabaseReference myRef3 = database.getReference(name+"/autoControl/lightTmp");//습도
        myRef3.addListenerForSingleValueEvent(new ValueEventListener() {//습도

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                data = dataSnapshot.getValue(String.class);//값 가져오기

                lightTmp.setText(data);//textview에 값 설정하기
            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        DatabaseReference myRef4 = database.getReference(name+"/autoControl/lightLux");//습도
        myRef4.addListenerForSingleValueEvent(new ValueEventListener() {//습도

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                data = dataSnapshot.getValue(String.class);//값 가져오기

                lightLux.setText(data);//textview에 값 설정하기
            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });



    }

}
