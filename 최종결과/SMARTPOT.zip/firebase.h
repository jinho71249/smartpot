#include <Firebase_Arduino_WiFiNINA.h>   //파이어베이스
#include <Firebase_Arduino_WiFiNINA_HTTPCLient.h>  //파이어베이스
#define FIREBASE_HOST "smart-pot-ac299.firebaseio.com" //파이어베이스 호스트
#define FIREBASE_AUTH "j9GEx03qAQnlotiJK4Vm1lQO4JZuZv6KoNGMcx2K" // 파이어베이스 비밀번호

void firebase(){
    
  }
