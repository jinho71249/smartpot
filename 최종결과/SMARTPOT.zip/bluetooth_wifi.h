#include <SoftwareSerial.h> //시리얼 통신 라이브러리 호출
#include <WiFiNINA.h>  //와이파이연동
char WIFI_SSID[32] ="";   //와이파이 주소
char WIFI_PASSWORD[32]="";  //와이파이 비밀번호   
String ID=""; 
String PW="";
String NAME = "";
int count=0;
int ID_count =0;
int PW_count =0;



int blueTx=2;   //Tx (보내는핀 설정)
int blueRx=3;   //Rx (받는핀 설정)
SoftwareSerial mySerial(blueTx, blueRx);  //시리얼 통신을 위한 객체선언

void bluetooth_wifi(){
  
  }
