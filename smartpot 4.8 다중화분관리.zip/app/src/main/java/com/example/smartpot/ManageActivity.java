package com.example.smartpot;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class ManageActivity extends AppCompatActivity {

    private ImageButton backBtn;
    private ListView listView;
    private ListaAdapter adapter;

    private String [] item;
    private String [] checks;
    private String potnames;
    private int num;
    int i;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference [] myRef;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.managelayout);
        adapter=new ListaAdapter();

        backBtn=findViewById(R.id.backBtn);
        listView=(ListView) findViewById(R.id.listview);
        Db data=(Db)getApplication();
        potnames=data.getPotNames();
        num=Integer.parseInt(data.getPotNum());

        item=new String[num];
        checks=new String[num];
        StringTokenizer tokens = new StringTokenizer(potnames, "#");
        i = 0;

        while (tokens.hasMoreTokens()) {
            item[i] = tokens.nextToken("#");
            i++;
        }


        listView.setAdapter(adapter);



        for(i=0;i<num;i++){

            Db checks=(Db)getApplication();
            adapter.addItem(item[i], R.mipmap.setting, "a");




        }



        adapter.notifyDataSetChanged();





        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//뒤로가기 버튼
                finish();
            }
        });


    }


    class ListaAdapter extends BaseAdapter{
        private ImageView iconView;
        private TextView potName1;
        private TextView mode1;
        ArrayList<Db> dbList=new ArrayList<Db>();

        public ListaAdapter(){ }

        public void addItem(String name, int icon, String mode){
            Db db=new Db();

            db.setName(name);
            db.setImage(icon);
            db.setMode(mode);

            dbList.add(db);
        }

        public View getView(int position, View cView, ViewGroup parent){
            final int pos=position;
            final Context context=parent.getContext();

            if(cView==null){
                LayoutInflater inflater=(LayoutInflater)context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
                cView=inflater.inflate(R.layout.listview, parent, false);
            }
            potName1=(TextView)cView.findViewById(R.id.potName1);
            iconView=(ImageView)cView.findViewById(R.id.image1);
            mode1=(TextView)cView.findViewById(R.id.mode1);

            iconView.setOnClickListener(new View.OnClickListener(){
                public void onClick(View v){
                    Intent intent=new Intent(getApplicationContext(), ControlActivity.class);
                    intent.putExtra("potnum", pos);
                    startActivityForResult(intent, 120);
                }
            });

            Db db=dbList.get(position);

            potName1.setText(db.getName());
            mode1.setText(db.getMode());
            iconView.setImageResource(db.getImage());

            return cView;
        }


        public int getCount(){
            return dbList.size();
        }


        public Object getItem(int i){
            return dbList.get(i);
        }

        public long getItemId(int position){
            return position;
        }



    }


}
