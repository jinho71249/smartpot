package com.example.smartpot;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class mngActivity extends AppCompatActivity {
    private PieChart wpieChart;
    private TextView selectedName;
    private ImageButton glassImg;
    private ImageButton rightBtn;
    private ImageButton leftBtn;
    private ImageButton modeBtn;
    private ImageButton waterBtn;
    private ImageButton lightBtn;
    private Switch alarmSwitch;
    protected String modecheck;
    protected String lightcheck;
    protected String item[];
    protected String selected;
    private String alarmcheck;
    protected int wlv;
    protected int num;
    protected int selectedNum;
    private String data;
    protected int ahumi;
    private Intent foregroundServiceIntent;
    static int PERCENT=100;



    FirebaseDatabase database = FirebaseDatabase.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mnglayout);
        initContent();
        initListener();
        setPieChart();
        readdata();


    }
    private void initContent(){
        glassImg=findViewById(R.id.glassImg);
        wpieChart=findViewById(R.id.piechart);
        alarmSwitch=findViewById(R.id.alarmSwitch);
        selectedName=findViewById(R.id.selectedName);
        rightBtn=findViewById(R.id.rightBtn);
        leftBtn=findViewById(R.id.leftBtn);
        modeBtn =findViewById(R.id.modeBtn);
        waterBtn=findViewById(R.id.waterBtn);
        lightBtn=findViewById(R.id.lightBtn);


        //waterBtn.setBackgroundResource(R.mipmap.wateringbtn);



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==201) {
            if (resultCode == 200) {
                final Db db = (Db) getApplication();
                Toast.makeText(getApplicationContext(), "화분이 추가됐습니다.", Toast.LENGTH_SHORT).show(); //테스트용
                readdata();

                final DatabaseReference myRef0 = database.getReference("admin/potAlarm");
                myRef0.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        String tmpcheck = dataSnapshot.getValue(String.class);
                        if(tmpcheck.equals("1")) {
                            myRef0.setValue("0");
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError error) {

                    }
                });
            }
        }
    }

    private void initListener(){
        final Db db=(Db)getApplication();
        Intent intent=getIntent();
        wlv=intent.getIntExtra("wlv", 0);
        //Toast.makeText(getApplicationContext(), Integer.toString(wlv), Toast.LENGTH_SHORT).show(); //테스트용

        selected =db.getSelectedPot();
        num=db.getPotNum();
        item=new String[num];
        for(int i=0;i<num;i++){
            item[i]=db.getIds(i);
        }
        for(int i=0;i<num;i++){
            if(selected.equals(item[i]))
                selectedNum=i;
        }


        selectedName.setText(db.getNames(selectedNum));
        glassImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), StateActivity.class);
                startActivity(intent);
            }
        });//상태창으로가는 돋보기 버튼

        rightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedNum++;
                if(selectedNum==num)
                    selectedNum=0;
                selected =item[selectedNum];
                db.setSelectedPot(selected);
                selectedName.setText(db.getNames(selectedNum));
                readdata();

            }
        });//다음 화분 버튼

        leftBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(selectedNum==0)
                    selectedNum=num-1;
                else
                    selectedNum--;
                selected =item[selectedNum];
                db.setSelectedPot(selected);
                selectedName.setText(db.getNames(selectedNum));
                readdata();

            }
        });//이전 화분 버튼

        lightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference myRef1 = database.getReference(selected + "/manualControl/lampSwitch");//조명 스위치
                if(modecheck.equals("1")) {
                    myRef1.setValue("0");
                }
                else {
                    myRef1.setValue("1");
                }

            }
        });//조명버튼

        waterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), WaterActivity.class);//수분공급 설성으로 이동
                //Toast.makeText(getApplicationContext(), Integer.toString(ahumi), Toast.LENGTH_SHORT).show();
                intent.putExtra("ahumi", ahumi);
                intent.putExtra("selectedNum", selectedNum);
                startActivity(intent);
            }
        });//수분공급 버튼

        modeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), ModeActivity.class);//모드 설성으로 이동
                intent.putExtra("selectedNum", selectedNum);
                startActivity(intent);
            }
        });//모드설정 버튼


        DatabaseReference myRef1 = database.getReference("admin/potAlarm");
        myRef1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                String data = dataSnapshot.getValue(String.class);//값 가져오기
                alarmcheck=data;
                if (alarmcheck.equals("1"))
                    alarmSwitch.setChecked(true);
                else
                    alarmSwitch.setChecked(false);
            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        alarmSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked){//스위치 버튼 동작
                DatabaseReference myRef1 = database.getReference("admin/potAlarm");
                if(isChecked) {
                    alarmcheck="1";
                    if (null == NotiService.serviceIntent) {
                        foregroundServiceIntent = new Intent(getApplicationContext(), NotiService.class);
                        startService(foregroundServiceIntent);
                        Toast.makeText(getApplicationContext(), "알림이 활성화됩니다", Toast.LENGTH_LONG).show();
                    } else {
                        foregroundServiceIntent = NotiService.serviceIntent;
                        Toast.makeText(getApplicationContext(), "이미 활성화되어있음", Toast.LENGTH_LONG).show();
                    }
                }
                else {
                    alarmcheck="0";
                    stopService(foregroundServiceIntent);
                    foregroundServiceIntent = null;
                    NotiService.serviceIntent=null;
                    Toast.makeText(getApplicationContext(), "알림이 비활성화됩니다.", Toast.LENGTH_LONG).show();
                }

                myRef1.setValue(alarmcheck);
            }
        });

    }

    private void setPieChart(){
        ArrayList chartContent=new ArrayList();
        chartContent.add(new PieEntry(wlv, "남은 물"));//데이터 추가
        chartContent.add(new PieEntry(PERCENT-wlv, "빈 공간"));

        PieDataSet dataSet=new PieDataSet(chartContent, null);//dataset에 데이터넣기
        PieData data=new PieData(dataSet);//파이데이터에 dataset넣기

        wpieChart.setData(data);
        wpieChart.setDrawCenterText(true); //원형그래프 안쪽에 글자 넣을 수 있게한다
        wpieChart.setCenterText("물탱크\n 수위 ");//글자넣기
        wpieChart.setCenterTextSize(23);//글자 크기
        wpieChart.setDescription(null);//그래프 설명 없애기
        wpieChart.setTransparentCircleRadius(0);//그래프 안쪽 입체감 0

        Legend legend=wpieChart.getLegend();//범례 가져오기
        legend.setEnabled(false); //범례 없애기
        dataSet.setColors(Color.rgb(77,145,227), Color.GRAY);
        //각 데이터에 원하는 색깔 넣기
    }

    protected void readdata(){
        final Db db=(Db)getApplication();
        selected =db.getSelectedPot();
        num=db.getPotNum();
        item=new String[num];
        for(int i=0;i<num;i++){
            item[i]=db.getIds(i);
        }

        DatabaseReference myRef1 = database.getReference(selected + "/potState/AHumi");//토양습도
        myRef1.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                ahumi=Integer.parseInt(data);

            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        DatabaseReference myRef2 = database.getReference(selected + "/potState/Wlevel");//수위
        myRef2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                wlv=Integer.parseInt(data);
                setPieChart();
                wpieChart.notifyDataSetChanged();
                wpieChart.invalidate();

            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        DatabaseReference myRef3 = database.getReference(selected + "/manualControl/lampSwitch");//조명 스위치
        myRef3.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                if(data!=null) {
                    modecheck=data;
                    if (modecheck.equals("0"))
                        lightBtn.setBackgroundResource(R.mipmap.lightbtn_off);
                    else
                        lightBtn.setBackgroundResource(R.mipmap.lightbtn_on);
                }

            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        DatabaseReference myRef4 = database.getReference(selected + "/ControlSwitch");//자,수동모드
        myRef4.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                if(data!=null) {
                    lightcheck=data;
                    if (lightcheck.equals("0")) {
                        modeBtn.setBackgroundResource(R.mipmap.modebtn_manual);
                        waterBtn.setEnabled(true);
                        lightBtn.setEnabled(true);
                    }
                    else {
                        modeBtn.setBackgroundResource(R.mipmap.modebtn_auto);
                        waterBtn.setEnabled(false);
                        lightBtn.setEnabled(false);
                    }
                }

            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });
    }//readdata

}

