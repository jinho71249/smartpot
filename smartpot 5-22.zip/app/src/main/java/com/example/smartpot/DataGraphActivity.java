package com.example.smartpot;


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.CombinedChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.CombinedData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class DataGraphActivity extends AppCompatActivity {
    private String[] date=new String[]{
            "5/22", "5/23", "5/24", "5/25", "5/26"
    };

    private CombinedChart combinedChart;
    private final int itemcount=5;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.datagraphlayout);

        combinedChart=findViewById(R.id.combinedChart);
        combinedChart.setDrawGridBackground(false);
        combinedChart.getDescription().setEnabled(false);
        combinedChart.setDrawBarShadow(false);
        combinedChart.setHighlightFullBarEnabled(false);

        combinedChart.setDrawOrder(new CombinedChart.DrawOrder[]{
                CombinedChart.DrawOrder.BAR, CombinedChart.DrawOrder.BUBBLE, CombinedChart.DrawOrder.CANDLE, CombinedChart.DrawOrder.LINE
        });

        Legend legend=combinedChart.getLegend();
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);

        YAxis rightAxis=combinedChart.getAxisRight();
        rightAxis.setDrawGridLines(false);
        rightAxis.setGranularity(200);
        rightAxis.setAxisMinimum(0);
        rightAxis.setAxisMaximum(1000);
        rightAxis.setDrawLabels(true);

        YAxis leftAxis=combinedChart.getAxisLeft();
        leftAxis.setDrawGridLines(false);
        leftAxis.setGranularity(20);
        leftAxis.setAxisMinimum(0);
        leftAxis.setAxisMaximum(100);

        XAxis xAxis=combinedChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTH_SIDED);
        xAxis.setAxisMinimum(0f);
        xAxis.setGranularity(1f);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(){
            @Override
            public String getFormattedValue(float value){
                return  date[(int)value%date.length];

            }
        });

        CombinedData cdata1=new CombinedData();

        LineData ldata=new LineData();

        ArrayList<Entry> lineEntry1=new ArrayList(); //data만들고 온도
        lineEntry1.add(new Entry(0, 14));
        lineEntry1.add(new Entry(1, 20));
        lineEntry1.add(new Entry(2, 24));
        lineEntry1.add(new Entry(3, 30));
        lineEntry1.add(new Entry(4, 36));

        ArrayList<Entry> lineEntry2=new ArrayList();//습도
        lineEntry2.add(new Entry(0, 27));
        lineEntry2.add(new Entry(1, 40));
        lineEntry2.add(new Entry(2, 48));
        lineEntry2.add(new Entry(3, 54));
        lineEntry2.add(new Entry(4, 68));

        ArrayList<Entry> lineEntry3=new ArrayList();//토양습도
        lineEntry3.add(new Entry(0, 87));
        lineEntry3.add(new Entry(1, 70));
        lineEntry3.add(new Entry(2, 58));
        lineEntry3.add(new Entry(3, 41));
        lineEntry3.add(new Entry(4, 46));

        ArrayList<Entry> lineEntry4=new ArrayList();//수위
        lineEntry4.add(new Entry(0, 34));
        lineEntry4.add(new Entry(1, 34));
        lineEntry4.add(new Entry(2, 34));
        lineEntry4.add(new Entry(3, 34));
        lineEntry4.add(new Entry(4, 34));

        LineDataSet dataSet1=new LineDataSet(lineEntry1, "온도");//data를 dataset에 넣고
        LineDataSet dataSet2=new LineDataSet(lineEntry2, "습도");
        LineDataSet dataSet3=new LineDataSet(lineEntry3, "토양습도");
        LineDataSet dataSet4=new LineDataSet(lineEntry4, "물탱크 수위");

        dataSet1.setLineWidth(2.5f);
        dataSet1.setColor(Color.rgb(153,252,54));
        dataSet1.setCircleColor(Color.rgb(153,252,54));
        dataSet1.setCircleHoleRadius(5f);
        dataSet1.setDrawValues(true);
        dataSet1.setValueTextSize(10f);
        dataSet1.setAxisDependency(YAxis.AxisDependency.LEFT);

        dataSet2.setLineWidth(2.5f);
        dataSet2.setColor(Color.rgb(234,238,68));
        dataSet2.setCircleColor(Color.rgb(234,238,68));
        dataSet2.setCircleHoleRadius(5f);
        dataSet2.setDrawValues(true);
        dataSet2.setValueTextSize(10f);
        dataSet2.setAxisDependency(YAxis.AxisDependency.LEFT);

        dataSet3.setLineWidth(2.5f);
        dataSet3.setColor(Color.rgb(255,204,255));
        dataSet3.setCircleColor(Color.rgb(255,204,255));
        dataSet3.setCircleHoleRadius(5f);
        dataSet3.setDrawValues(true);
        dataSet3.setValueTextSize(10f);
        dataSet3.setAxisDependency(YAxis.AxisDependency.LEFT);

        dataSet4.setLineWidth(2.5f);
        dataSet4.setColor(Color.rgb(255,153,102));
        dataSet4.setCircleColor(Color.rgb(255,153,102));
        dataSet4.setCircleHoleRadius(5f);

        dataSet4.setDrawValues(true);
        dataSet4.setValueTextSize(10f);
        dataSet4.setAxisDependency(YAxis.AxisDependency.LEFT);

        ldata.addDataSet(dataSet1); //linedata에 넣고
        ldata.addDataSet(dataSet2);
        ldata.addDataSet(dataSet3);
        ldata.addDataSet(dataSet4);

        BarData bdata=new BarData();
        ArrayList<BarEntry> barEntry=new ArrayList<BarEntry>();
        barEntry.add(new BarEntry(0+.1f, 789));
        barEntry.add(new BarEntry(1+.1f, 863));
        barEntry.add(new BarEntry(2+.1f, 925));
        barEntry.add(new BarEntry(3+.1f, 469));
        barEntry.add(new BarEntry(4+.1f, 779));

        BarDataSet dataSet5=new BarDataSet(barEntry,"조도");
        dataSet5.setValueTextSize(10f);
        dataSet5.setColor(Color.rgb(102,204,255));
        dataSet5.setAxisDependency(YAxis.AxisDependency.RIGHT);

        bdata.setBarWidth(.2f);
        bdata.addDataSet(dataSet5);

        cdata1.setData(ldata); //combineddata에 넣고
        cdata1.setData(bdata);

        combinedChart.setData(cdata1);//combined차트에 넣는다
        combinedChart.invalidate();//차트 활성화

    }//oncreate


}
