package com.example.smartpot;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class StateActivity extends AppCompatActivity {
    private Spinner spinner;
    private ImageButton backBtn;
    protected String name;//식물이름
    private String data;//파이어베이스에서 값 가져올때 임시변수
    private TextView ahumi;//습도
    private TextView temp;//온도
    private TextView lux;//조도
    private TextView shumi;//토양습도
    private TextView wLevel;//수위
    protected int wlv;
    private String item[]; //식물 이름 배열
    private int num; //화분갯수
    protected int selectedNum;
    private Intent foregroundServiceIntent;


    FirebaseDatabase database = FirebaseDatabase.getInstance();


    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.statelayout);
        final Db db=(Db)getApplication();
        //Toast.makeText(getApplicationContext(), db.getSelectedPot(), Toast.LENGTH_SHORT).show(); //테스트용

        initContent();
        initListener();

        name=db.getSelectedPot();

        readData();

        //Toast.makeText(getApplicationContext(), "만드는중", Toast.LENGTH_SHORT).show(); //테스트용
    }

    @Override
    protected void onResume() {
        super.onResume();
        final Db db=(Db)getApplication();
        for(int i=0;i<num;i++){
            if(db.getSelectedPot().equals(item[i]))
                selectedNum=i;
        }
        spinner.setSelection(selectedNum);
    }


    private void initContent(){ //xml과 동기화
        spinner=findViewById((R.id.spinner));
        ahumi=findViewById((R.id.ahumi));
        temp=findViewById((R.id.temp));
        lux=findViewById((R.id.lux));
        shumi=findViewById((R.id.shumi));
        wLevel=findViewById((R.id.wLevel));
        backBtn=findViewById(R.id.backBtn);
    }

    private void initListener(){//버튼이나 textview동작

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });//back버튼

    }

    public void readData() { //상태값 파이어베이스에서 읽어오기
        final Db db=(Db)getApplication();
        name=db.getSelectedPot();
        num=db.getPotNum();
        item=new String[num];
        for(int i=0;i<num;i++){
            item[i]=db.getNames(i);
        }


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                db.setSelectedPot(parent.getItemAtPosition(position).toString());//선택된 이름 전역변수에 저장

                DatabaseReference myRef3 = database.getReference(name + "/potState/AHumi");//습도
                DatabaseReference myRef4 = database.getReference(name + "/potState/temp");//온도
                DatabaseReference myRef5 = database.getReference(name + "/potState/lux");//조도
                DatabaseReference myRef6 = database.getReference(name + "/potState/SHumi");//토양습도
                DatabaseReference myRef7 = database.getReference(name + "/potState/Wlevel");//수위

                myRef3.addValueEventListener(new ValueEventListener() {//습도

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                        data = dataSnapshot.getValue(String.class);//값 가져오기

                        ahumi.setText(data);//textview에 값 설정하기
                        ahumi.setTextColor(Color.BLACK);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
                    }
                });


                myRef4.addValueEventListener(new ValueEventListener() {//온도

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        data = dataSnapshot.getValue(String.class);

                        temp.setText(data);
                        temp.setTextColor(Color.BLACK);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                    }
                });

                myRef5.addValueEventListener(new ValueEventListener() {//온도

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        data = dataSnapshot.getValue(String.class);

                        lux.setText(data);
                        lux.setTextColor(Color.BLACK);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                    }
                });


                myRef6.addValueEventListener(new ValueEventListener() {//토양습도

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        data = dataSnapshot.getValue(String.class);

                        shumi.setText(data);
                        shumi.setTextColor(Color.BLACK);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                    }
                });


                myRef7.addValueEventListener(new ValueEventListener() {//수위

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        data = dataSnapshot.getValue(String.class);
                        if(data!=null) {
                            wLevel.setText(data);
                            db.setWlv(data);
                            wlv = Integer.parseInt(db.getWlv());
                            if (wlv <= 30)
                                wLevel.setTextColor(Color.RED);
                            else
                                wLevel.setTextColor(Color.BLACK);
                        }
                    }
                    @Override
                    public void onCancelled(DatabaseError error) {
                    }
                });


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {//화분이 등록안돼 있을 경우에만 작동
                //이런 경우 없음
            }
        });

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(StateActivity.this, R.layout.spinner_item, item);
        adapter.setDropDownViewResource(R.layout.spinner_item);//스피너 적용
        spinner.setAdapter(adapter);


    }//readdata종료




}
