package com.example.smartpot;

import android.app.Application;



public class Db extends Application {

    private String potNames; //모든 화분이름이 있는 값 가져오기
    private int potNum;   //화분 갯수
    private String selectedPot; //선택된 화분
    private int image;       //설정버튼 이미지
    private String wlv;      //수위값
    private String name;     //화분이름(리스트뷰에서)
    private String mode;    //화분 제어모드
    private String names[]=new String[100]; //화분이름을 하나하나 저장한 배열
    private String checks[]=new String[100]; //화분 제어모드 값들 저장 배열
    private boolean alertCheck[]=new boolean[100];//물탱크가 30%이하인 화분 체크
    private int alertchecknum=0;//알림체크 배열 번호
    private int namesnum =0;  //name배열 번호
    private int checknum =0;  //check배열 번호
    private int deletenum;  //화분 데이터 삭제 번호
    private String alertcontent; //물부족알림메시지

    public String getAlertcontent() {
        return alertcontent;
    }

    public void setAlertcontent(String alertcontent) {
        this.alertcontent = alertcontent;
    }

    public int getDeletenum() {
        return deletenum;
    }

    public void setDeletenum(int deletenum) {
        this.deletenum = deletenum;
    }

    public String getWlv() {
        return wlv;
    }

    public void setWlv(String wlv) {
        this.wlv = wlv;
    }

    public String getNames(int i) {
        return names[i];
    }

    public String getChecks(int i) {
        return checks[i];
    }

    public boolean getAlertCheck(int i) {
        return alertCheck[i];
    }

    public void setAlertCheck(boolean alertCheck) {
        this.alertCheck[alertchecknum++] = alertCheck;
    }

    public int getAlertchecknum() {
        return alertchecknum;
    }

    public void setAlertchecknum(int alertchecknum) {
        this.alertchecknum = alertchecknum;
    }

    public int getNamesnum() {
        return namesnum;
    }

    public void setNamesnum(int namesnum) {
        this.namesnum = namesnum;
    }

    public void setNames(String names) {
        this.names[namesnum++] = names;
    }

    public void setChecks(String checks) {
        this.checks[checknum++] = checks;
    }

    public int getChecknum() {
        return checknum;
    }

    public void setChecknum(int checknum) {
        this.checknum = checknum;
    }

    public Db(){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getSelectedPot() {
        return selectedPot;
    }

    public void setSelectedPot(String selectedPot) {
        this.selectedPot = selectedPot;
    }

    public String getPotNames() {
        return potNames;
    }

    public void setPotNames(String potNames) {
        this.potNames = potNames;
    }

    public int getPotNum() {
        return potNum;
    }

    public void setPotNum(int potNum) {
        this.potNum = potNum;
    }





}
