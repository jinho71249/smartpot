package com.example.smartpot;


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class WaterActivity extends AppCompatActivity {
    protected PieChart lpieChart;
    private TextView selectedName;
    private EditText waterContent;
    private ImageButton supplyBtn;
    private ImageView backBtn;
    protected String name;
    private String watercontent;

    private String data;
    protected int ahumi;
    static int PERCENT=100;

    FirebaseDatabase database = FirebaseDatabase.getInstance();


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.waterlayout);
        final Db db=(Db)getApplication();

        Intent intent=getIntent();
        ahumi=intent.getIntExtra("ahumi", 0);
        //Toast.makeText(getApplicationContext(), Integer.toString(ahumi), Toast.LENGTH_SHORT).show();테스트

        initContent();
        initListener();
        setPieChart();

    }

    private void initContent(){
        lpieChart=findViewById(R.id.piechart);
        waterContent=findViewById(R.id.waterContent);
        selectedName=findViewById(R.id.selectedName);
        supplyBtn=findViewById(R.id.wsupplyBtn);
        backBtn=findViewById(R.id.backBtn);
    }

    private void initListener(){
        final Db db=(Db)getApplication();
        name=db.getSelectedPot();

        selectedName.setText(name);

        supplyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                watercontent= waterContent.getText().toString();

                DatabaseReference myRef1 = database.getReference(name+"/manualControl/waterContent");
                myRef1.setValue(watercontent);

                Toast.makeText(getApplicationContext(), "수분공급량 전송.", Toast.LENGTH_SHORT).show();
                finish();
            }
        });//수분공급 버튼



        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });//back버튼
    }

    private void setPieChart(){

        ArrayList chartContent=new ArrayList();
        chartContent.add(new PieEntry(ahumi, "토양습도"));
        chartContent.add(new PieEntry(PERCENT-ahumi, ""));

        PieDataSet dataSet=new PieDataSet(chartContent, null);
        PieData data=new PieData(dataSet);

        lpieChart.setData(data);
        lpieChart.setDrawCenterText(true);
        lpieChart.setCenterText("test");
        lpieChart.setDescription(null);
        lpieChart.setEntryLabelTextSize(10);
        lpieChart.setTransparentCircleRadius(0);//그래프 안쪽 입체감 0
        lpieChart.setCenterTextSize(40);

        Legend legend=lpieChart.getLegend();
        legend.setEnabled(false);

        dataSet.setColors(Color.rgb(77,145,227), Color.GRAY);

        //lpieChart.notifyDataSetChanged();
        //lpieChart.invalidate();//refresh??
    }




}
