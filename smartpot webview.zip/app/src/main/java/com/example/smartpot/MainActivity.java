package com.example.smartpot;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    private ImageButton controlBtn;
    private ImageButton stateBtn;
    private ImageButton searchBtn;
    //private ImageButton autoBtn;
    private String data;

    private String mngCheck="1";


    FirebaseDatabase database = FirebaseDatabase.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);


        initContent();
        initListener();
        readdata();




    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


    }

    private void initCatcher() {
        // 오류 발생시 프로그램을 강제로 종료시킵니다.
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(@NonNull Thread thread, @NonNull Throwable throwable) {
                System.exit(0);
            }
        });
    }

    private void initContent() {//xml하고 변수 연동
        controlBtn=findViewById(R.id.controlBtn);
        stateBtn=findViewById(R.id.stateBtn);
        searchBtn=findViewById(R.id.searchBtn);

    }

    private void initListener(){//버튼 설정
        controlBtn.setOnClickListener(new View.OnClickListener(){//관리모드버튼
            public void onClick(View v){
                Intent intent=new Intent(getApplicationContext(), ManageActivity.class);
                startActivityForResult(intent, 101);
            }
        });

        stateBtn.setOnClickListener(new View.OnClickListener(){//식물인식버튼
            public void onClick(View v){
                Intent intent=new Intent(getApplicationContext(), RegActivity.class);
                startActivityForResult(intent, 102);
            }
        });

        searchBtn.setOnClickListener(new View.OnClickListener(){//수분공급버튼
            public void onClick(View v){
                Intent intent=new Intent(getApplicationContext(), SearchActivity.class);
                startActivityForResult(intent, 103);

            }
        });





    }

     public void readdata(){//
         DatabaseReference myRef1 = database.getReference("admin/potName");
         myRef1.addValueEventListener(new ValueEventListener() {

             @Override
             public void onDataChange(DataSnapshot dataSnapshot) {
                 if(dataSnapshot.exists()) {
                     Db db=(Db)getApplicationContext();
                     data = dataSnapshot.getValue(String.class);
                     db.setPotNames(data);

                 }
                 else
                     Toast.makeText(getApplicationContext()
                             , "그런 데이터없음"
                             , Toast.LENGTH_SHORT).show();
             }
             @Override
             public void onCancelled(DatabaseError error) {

             }
         });

         DatabaseReference myRef2 = database.getReference("admin/potNum");
         myRef2.addValueEventListener(new ValueEventListener() {

             @Override
             public void onDataChange(DataSnapshot dataSnapshot) {
                 if(dataSnapshot.exists()) {
                     Db db=(Db)getApplication();
                     data = dataSnapshot.getValue(String.class);
                     db.setPotNum(data);
                 }
                 else
                     Toast.makeText(getApplicationContext()
                             , "경로오류"
                             , Toast.LENGTH_SHORT).show();
             }
             @Override
             public void onCancelled(DatabaseError error) {
             }
         });








     }


}


//<TextView
//            android:id="@+id/test"
//            android:layout_width="wrap_content"
//            android:layout_height="wrap_content"
//            android:layout_weight="1"/>