package com.example.smartpot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.StringTokenizer;


public class StateActivity extends AppCompatActivity {
    private ImageButton backBtn;
    //private ImageButton saveBtn;
    private TextView plantName;
    private String name;//식물이름
    private String data;//파이어베이스에서 값 가져올때 임시변수
    private TextView ahumi;//습도
    private TextView temp;//온도
    private TextView lux;//조도
    private TextView shumi;//토양습도
    private TextView wLevel;//수위
    private int wlv;

    FirebaseDatabase database = FirebaseDatabase.getInstance();


    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.statelayout);
        final Db db=(Db)getApplication();
        initContent();
        initListener();
        readData();


        name=db.getSelectedPot();
        plantName.setText(name);
    }

    private void initContent(){ //xml과 동기화
        backBtn=findViewById(R.id.backBtn);
        //saveBtn=findViewById(R.id.saveBtn);
        plantName=findViewById(R.id.plantName);
        ahumi=findViewById((R.id.ahumi));
        temp=findViewById((R.id.temp));
        lux=findViewById((R.id.lux));
        shumi=findViewById((R.id.shumi));
        wLevel=findViewById((R.id.wLevel));
    }

    private void initListener(){//버튼이나 textview동작
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {//뒤로가기 버튼
                Intent intent = new Intent();
                setResult(RESULT_FIRST_USER, intent);
                finish();
            }
        });

    }

    public void readData() { //상태값 파이어베이스에서 읽어오기
        final Db db1=(Db)getApplication();
        name=db1.getSelectedPot();


        DatabaseReference myRef3 = database.getReference(name + "/potState/AHumi");//습도
        DatabaseReference myRef4 = database.getReference(name + "/potState/temp");//온도
        DatabaseReference myRef5 = database.getReference(name + "/potState/lux");//조도
        DatabaseReference myRef6 = database.getReference(name + "/potState/SHumi");//토양습도
        DatabaseReference myRef7 = database.getReference(name + "/potState/Wlevel");//수위
        //DatabaseReference myRef8 = database.getReference("manualControl/plantName");//식물이름 불어오기

        myRef3.addValueEventListener(new ValueEventListener() {//습도

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                data = dataSnapshot.getValue(String.class);//값 가져오기

                ahumi.setText(data);//textview에 값 설정하기
                ahumi.setTextColor(Color.BLACK);
            }

            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });


        myRef4.addValueEventListener(new ValueEventListener() {//온도

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);

                temp.setText(data);
                temp.setTextColor(Color.BLACK);
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });

        myRef5.addValueEventListener(new ValueEventListener() {//온도

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);

                lux.setText(data);
                lux.setTextColor(Color.BLACK);
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });


        myRef6.addValueEventListener(new ValueEventListener() {//토양습도

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);

                shumi.setText(data);
                shumi.setTextColor(Color.BLACK);
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });


        myRef7.addValueEventListener(new ValueEventListener() {//수위

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                data = dataSnapshot.getValue(String.class);
                wLevel.setText(data);
                db1.setWlv(data);

                wlv = Integer.parseInt(db1.getWlv());
                if (wlv <= 30) {
                    wLevel.setTextColor(Color.RED);
//
                    notificationCannel();
                } else
                    wLevel.setTextColor(Color.BLACK);
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });


        //myRef8.addValueEventListener(new ValueEventListener() {//수위
//
        //       @Override
        //       public void onDataChange(DataSnapshot dataSnapshot) {
        //           data = dataSnapshot.getValue(String.class);
//
        //           plantName.setText(data);
        //       }
        //       @Override
        //       public void onCancelled(DatabaseError error) {
        //       }
        //   });


    }

    public void notificationCannel(){
        NotificationManager notificationManager=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(StateActivity.this, "notiID")
                .setContentText("물 탱크에 물이 부족합니다.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            builder.setSmallIcon(R.drawable.ic_launcher_foreground); //mipmap 사용시 Oreo 이상에서 시스템 UI 에러남
            CharSequence channelName  = "노티페케이션 채널";
            String description = "오레오 이상을 위한 것임";
            int importance = NotificationManager.IMPORTANCE_HIGH;

            NotificationChannel channel = new NotificationChannel("notiID", channelName , importance);
            channel.setDescription(description);

            // 노티피케이션 채널을 시스템에 등록
            assert notificationManager != null;
            notificationManager.createNotificationChannel(channel);

        }else builder.setSmallIcon(R.mipmap.ic_launcher); // Oreo 이하에서 mipmap 사용하지 않으면 Couldn't create icon: StatusBarIcon 에러남

        assert notificationManager != null;
        notificationManager.notify(1234, builder.build());

    }




}
