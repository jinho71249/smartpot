package com.example.smartpot;

import android.app.Application;



public class Db extends Application {

    private String potNames;
    private String potNum;
    private String selectedPot;
    private int image;
    private String wlv;
    private String name;
    private String mode;
    private String check[]=new String[100];
    private int checknum=0;
    public void usecheck(){
        for(int i=0;i<100;i++){
            check[i]="3";
        }
    }
    public String getWlv() {
        return wlv;
    }

    public void setWlv(String wlv) {
        this.wlv = wlv;
    }

    public String getCheck(int i) {
        return check[i];
    }

    public int getChecknum() {
        return checknum;
    }

    public void setCheck(String check) {
        this.check[checknum++] = check;
    }

    public Db(){}


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getSelectedPot() {
        return selectedPot;
    }

    public void setSelectedPot(String selectedPot) {
        this.selectedPot = selectedPot;
    }

    public String getPotNames() {
        return potNames;
    }

    public void setPotNames(String potNames) {
        this.potNames = potNames;
    }

    public String getPotNum() {
        return potNum;
    }

    public void setPotNum(String potNum) {
        this.potNum = potNum;
    }






}
