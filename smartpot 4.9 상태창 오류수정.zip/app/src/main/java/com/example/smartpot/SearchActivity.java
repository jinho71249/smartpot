package com.example.smartpot;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;



// HttpClient libraries



import com.google.common.io.ByteStreams;
import com.google.gson.Gson;
import com.microsoft.azure.cognitiveservices.search.visualsearch.BingVisualSearchAPI;
import com.microsoft.azure.cognitiveservices.search.visualsearch.BingVisualSearchManager;
import com.microsoft.azure.cognitiveservices.search.visualsearch.models.CropArea;
import com.microsoft.azure.cognitiveservices.search.visualsearch.models.ErrorResponseException;
import com.microsoft.azure.cognitiveservices.search.visualsearch.models.Filters;
import com.microsoft.azure.cognitiveservices.search.visualsearch.models.ImageInfo;
import com.microsoft.azure.cognitiveservices.search.visualsearch.models.ImageKnowledge;
import com.microsoft.azure.cognitiveservices.search.visualsearch.models.ImageTag;
import com.microsoft.azure.cognitiveservices.search.visualsearch.models.KnowledgeRequest;
import com.microsoft.azure.cognitiveservices.search.visualsearch.models.VisualSearchRequest;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;


public class SearchActivity extends AppCompatActivity {
    private ImageButton searchButton;
    private ImageButton imageOpenButton;
    private ImageButton backBtn;
    private ImageView imageView;
    private Bitmap bitmap;
    private byte[] imageBytes;
    private final int GET_GALLERY_IMAGE = 200;

    static String endpoint = "https://smartpot1.cognitiveservices.azure.com/bing/v7.0";
    static String subscriptionKey = "2c790c77ff484ab2b966fd5fc00a05d0";
    static String imagePath = "C:\\Users\\qwe\\Desktop\\test.jpg";





    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.searchlayout);
        initContent();
        initListener();

        BingVisualSearchAPI client = BingVisualSearchManager.authenticate(subscriptionKey);






    }


    public void visualSearch(BingVisualSearchAPI client, byte[] imageBytes){
        System.out.println("Calling Bing Visual Search with image binary");
        ImageKnowledge visualSearchResults = client.bingImages().visualSearch()
                .withImage(imageBytes)
                .execute();
        PrintVisualSearchResults(visualSearchResults);

    }
    public void PrintVisualSearchResults(ImageKnowledge visualSearchResults) {
        if (visualSearchResults == null) {
            Toast.makeText(SearchActivity.this, "No visual search result data.", Toast.LENGTH_SHORT).show();
        } else {
            // Print token

            if (visualSearchResults.image() != null && visualSearchResults.image().imageInsightsToken() != null) {
                Toast.makeText(SearchActivity.this, "Found uploaded image insights token: ", Toast.LENGTH_SHORT).show();
                System.out.println("Found uploaded image insights token: " + visualSearchResults.image().imageInsightsToken());
            } else {
                System.out.println("Couldn't find image insights token!");
                Toast.makeText(SearchActivity.this, "Couldn't find image insights token!", Toast.LENGTH_SHORT).show();
            }
            // List tags
            if (visualSearchResults.tags() != null && visualSearchResults.tags().size() > 0) {
                System.out.format("Found visual search tag count: %d\n", visualSearchResults.tags().size());
                ImageTag firstTagResult = visualSearchResults.tags().get(0);

                // List of actions in first tag

                if (firstTagResult.actions() != null && firstTagResult.actions().size() > 0) {
                    System.out.format("Found first tag action count: %d\n", firstTagResult.actions().size());
                    System.out.println("Found first tag action type: " + firstTagResult.actions().get(0).actionType());
                }
            } else {
                System.out.println("Couldn't find image tags!");
            }
        }
    }



    private void initContent(){
        searchButton=findViewById(R.id.searchButton);
        imageOpenButton=findViewById(R.id.imageOpenButton);
        imageView=findViewById(R.id.imageView);
        backBtn=findViewById(R.id.backBtn);
    }



    private void initListener(){

        searchButton.setOnClickListener(new View.OnClickListener() {
            BingVisualSearchAPI client = BingVisualSearchManager.authenticate(subscriptionKey);

            @Override
            public void onClick(View v) {
                visualSearch(client, imageBytes);
            }
        });

                //try {
                //imageBytes = ByteStreams.toByteArray(ClassLoader.getSystemClassLoader().getResourceAsStream("drawable/test.jpg"));
                    //searchWithCropArea(client, imageBytes);
                    //    // wait 1 second to avoid rate limiting
                    //Thread.sleep(1000);
                    //searchWithFilter(client);
                    //searchUsingCropArea(client);
                    //searchUsingInsightToken(client);
                //}
                //catch (java.io.IOException f) {
                //    System.out.println(f.getMessage());
                //    f.printStackTrace();
                //}
                //catch (java.lang.InterruptedException f){
                //    f.printStackTrace();
                //}




        imageOpenButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent. setDataAndType(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                startActivityForResult(intent, GET_GALLERY_IMAGE);
            }
        });

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent out = new Intent();
                setResult(RESULT_CANCELED, out);
                finish();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == GET_GALLERY_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {

            Uri selectedImageUri = data.getData();
            imageView.setImageURI(selectedImageUri);

            BitmapDrawable d=(BitmapDrawable) imageView.getDrawable();
            bitmap=d.getBitmap();
            ByteBuffer buffer=ByteBuffer.allocate(bitmap.getByteCount());
            bitmap.copyPixelsToBuffer(buffer);
            imageBytes=buffer.array();
        }
    }

}
//try {
//}
//catch (IOException e){
//    e.printStackTrace();
//}