package com.example.smartpot;

import android.app.Activity;
import android.app.Application;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.StringTokenizer;

import app.akexorcist.bluetotohspp.library.BluetoothSPP;
import app.akexorcist.bluetotohspp.library.BluetoothState;
import app.akexorcist.bluetotohspp.library.DeviceList;

public class BluetoothActivity extends AppCompatActivity {

    private BluetoothSPP bt;
    private Button btnConnect;
    private Button btnSend;
    private EditText internetID;
    private EditText internetPW;
    private EditText potName;
    private String id;
    private String pw;
    public String potname;
    public int potNum;
    private String data;

    String[] item=new String[3];
    int i;
    private String potnames;


    FirebaseDatabase database = FirebaseDatabase.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bluetooth);
        initContent();



        DatabaseReference myRef1 = database.getReference("admin/potNum");
        myRef1.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    Db db=(Db)getApplication();
                    data = dataSnapshot.getValue(String.class);
                    db.setPotNum(data);
                }
                else
                    Toast.makeText(getApplicationContext()
                            , "경로오류"
                            , Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });
        DatabaseReference myRef2 = database.getReference("admin/potName");
        myRef2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    data = dataSnapshot.getValue(String.class);
                    Db db=(Db)getApplication();
                    db.setPotNames(data);


                }
                else
                    Toast.makeText(getApplicationContext()
                            , "그런 데이터없음"
                            , Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onCancelled(DatabaseError error) {
            }
        });









        bt = new BluetoothSPP(this); //Initializing

        if (!bt.isBluetoothAvailable()) { //블루투스 사용 불가
            Toast.makeText(getApplicationContext()
                    , "Bluetooth is not available"
                    , Toast.LENGTH_SHORT).show();
            //finish();
        }

        bt.setOnDataReceivedListener(new BluetoothSPP.OnDataReceivedListener() { //데이터 수신
            public void onDataReceived(byte[] data, String message) {
                Toast.makeText(BluetoothActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });

        bt.setBluetoothConnectionListener(new BluetoothSPP.BluetoothConnectionListener() { //연결됐을 때
            public void onDeviceConnected(String name, String address) {
                Toast.makeText(getApplicationContext()
                        , "Connected to " + name + "\n" + address
                        , Toast.LENGTH_SHORT).show();
            }

            public void onDeviceDisconnected() { //연결해제
                Toast.makeText(getApplicationContext()
                        , "Connection lost", Toast.LENGTH_SHORT).show();
            }

            public void onDeviceConnectionFailed() { //연결실패
                Toast.makeText(getApplicationContext()
                        , "Unable to connect", Toast.LENGTH_SHORT).show();
            }
        });


        btnConnect.setOnClickListener(new View.OnClickListener() {//연결시도
            public void onClick(View v) {
                if (bt.getServiceState() == BluetoothState.STATE_CONNECTED) {
                    bt.disconnect();
                } else {
                    Intent intent = new Intent(getApplicationContext(), DeviceList.class);
                    startActivityForResult(intent, BluetoothState.REQUEST_CONNECT_DEVICE);
                }
            }
        });
    }



    private void initContent(){
        btnConnect = findViewById(R.id.btnConnect);
        btnSend = findViewById(R.id.btnSend);
        internetID=findViewById(R.id.internetID);
        internetPW=findViewById(R.id.internetPW);
        potName=findViewById(R.id.potName);
    }

    public void onDestroy() {
        super.onDestroy();
        bt.stopService(); //블루투스 중지
    }

    public void onStart() {
        super.onStart();
        if (!bt.isBluetoothEnabled()) { //
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent, BluetoothState.REQUEST_ENABLE_BT);
        } else {
            if (!bt.isServiceAvailable()) {
                bt.setupService();
                bt.startService(BluetoothState.DEVICE_OTHER); //DEVICE_ANDROID는 안드로이드 기기 끼리
                setup();
            }
        }

    }




    public void setup() {

        btnSend.setOnClickListener(new View.OnClickListener() {//데이터 전송
            public void onClick(View v) {
                Db db=(Db)getApplication();
                id=internetID.getText().toString();
                pw=internetPW.getText().toString();
                potname=potName.getText().toString();
                potNum=Integer.parseInt(db.getPotNum());
                potNum++;



                bt.send(id +"/"+pw+"#"+potname+"$", true);
                DatabaseReference myRef8 = database.getReference("admin/potNum");
                myRef8.setValue(Integer.toString(potNum));

                DatabaseReference myRef9 = database.getReference(potname+"/WaterData/watercheck");
                myRef9.setValue("1");
                DatabaseReference myRef10 = database.getReference("admin/potName");
                myRef10.setValue(db.getPotNames()+"#"+potname);

                DatabaseReference myRef11 = database.getReference(potname+"/autoControl/autoWpercent");
                myRef11.setValue("1");
                DatabaseReference myRef12 = database.getReference(potname+"/autoControl/autoWcontent");
                myRef12.setValue("1");
                DatabaseReference myRef13 = database.getReference(potname+"/autoControl/lightTmp");
                myRef13.setValue("1");
                DatabaseReference myRef14 = database.getReference(potname+"/potState/AHumi");
                myRef14.setValue("1");
                DatabaseReference myRef15 = database.getReference(potname+"/potState/temp");
                myRef15.setValue("1");
                DatabaseReference myRef16 = database.getReference(potname+"/potState/lux");
                myRef16.setValue("1");
                DatabaseReference myRef17 = database.getReference(potname+"/potState/SHumi");
                myRef17.setValue("1");
                DatabaseReference myRef18 = database.getReference(potname+"/potState/Wlevel");
                myRef18.setValue("1");
                DatabaseReference myRef19 = database.getReference(potname+"/manualControl/plantName");
                myRef19.setValue("1");
                DatabaseReference myRef20 = database.getReference(potname+"/manualControl/lampSwitch");
                myRef20.setValue("1");
                DatabaseReference myRef21 = database.getReference(potname+"/ControlSwitch");
                myRef21.setValue("1");
                DatabaseReference myRef22 = database.getReference(potname+"/manualControl/pumpSwitch");
                myRef22.setValue("1");
                DatabaseReference myRef23 = database.getReference(potname+"/manualControl/waterContent");
                myRef23.setValue("1");
                DatabaseReference myRef24 = database.getReference(potname+"/WaterData/watercheck");
                myRef24.setValue("1");

                finish();
            }
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == BluetoothState.REQUEST_CONNECT_DEVICE) {
            if (resultCode == Activity.RESULT_OK)
                bt.connect(data);
        } else if (requestCode == BluetoothState.REQUEST_ENABLE_BT) {
            if (resultCode == Activity.RESULT_OK) {
                bt.setupService();
                bt.startService(BluetoothState.DEVICE_OTHER);
                setup();
            } else {
                Toast.makeText(getApplicationContext()
                        , "Bluetooth was not enabled."
                        , Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

}


