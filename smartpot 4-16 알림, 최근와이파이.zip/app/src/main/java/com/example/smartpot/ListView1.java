package com.example.smartpot;

import android.content.Context;
import android.content.Intent;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.jar.Attributes;

public class ListView1 extends LinearLayout {
    TextView potName;
    TextView mode;
    ImageView image;

    public ListView1(Context context){
        super(context);
        init(context);
    }

    public ListView1(Context context, AttributeSet attrs){
        super(context, attrs);
        init(context);
    }

    public void init(Context context){
        LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.listview,this,true);

        potName=findViewById(R.id.potName1);
        mode=findViewById(R.id.mode1);
        image=findViewById(R.id.image1);
    }

    public void setItem(Db Db){
        potName.setText(Db.getName()); //이름 설정
        mode.setText(Db.getMode());     //제어모드 설정
        image.setImageResource(Db.getImage()); //설정 이미지
    }
}
