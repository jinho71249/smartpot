package com.example.smartpot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AutoActivity extends AppCompatActivity {
    private ImageButton saveBtn;
    private ImageButton backBtn;
    private EditText autoWpercent;
    private EditText autoWcontent;
    private EditText lightTmp;
    private String autoWPercent;
    private String autoWContent;
    private String lighttmp;
    private String data;

    FirebaseDatabase database = FirebaseDatabase.getInstance();


    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.autolayout);
        initContent();
        initListener();
    }

    private void initContent(){
        saveBtn=findViewById(R.id.saveBtn);
        backBtn=findViewById(R.id.backBtn);
        autoWpercent=findViewById(R.id.autoWpercent);
        autoWcontent=findViewById(R.id.autoWcontent);
        lightTmp=findViewById(R.id.lightTmp);

    }

    private void initListener(){

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference myRef1 = database.getReference("ControlSwitch");
                myRef1.setValue("0");
                DatabaseReference myRef2 = database.getReference("manualControl/lampSwitch");
                myRef2.setValue("0");

                Intent out = new Intent();
                setResult(RESULT_CANCELED, out);
                finish();
            }
        });

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                autoWPercent=autoWpercent.getText().toString();
                autoWContent=autoWcontent.getText().toString();
                lighttmp=lightTmp.getText().toString();

                DatabaseReference myRef1 = database.getReference("autoControl/autoWpercent"); //파이어베이스로 값전달
                myRef1.setValue(autoWPercent);
                DatabaseReference myRef2 = database.getReference("autoControl/autoWcontent"); //파이어베이스로 값전달
                myRef2.setValue(autoWContent);
                DatabaseReference myRef3 = database.getReference("autoControl/lightTmp"); //파이어베이스로 값전달
                myRef3.setValue(lighttmp);

                //setResult(RESULT_OK, intent);
                finish();
            }
        });//저장버튼


        DatabaseReference myRef1 = database.getReference("autoControl/autoWpercent");//습도
        myRef1.addValueEventListener(new ValueEventListener() {//습도

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                data = dataSnapshot.getValue(String.class);//값 가져오기

                autoWpercent.setText(data);//textview에 값 설정하기
            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        DatabaseReference myRef2 = database.getReference("autoControl/autoWcontent");//습도
        myRef2.addValueEventListener(new ValueEventListener() {//습도

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                data = dataSnapshot.getValue(String.class);//값 가져오기

                autoWcontent.setText(data);//textview에 값 설정하기
            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        DatabaseReference myRef3 = database.getReference("autoControl/lightTmp");//습도
        myRef3.addValueEventListener(new ValueEventListener() {//습도

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                data = dataSnapshot.getValue(String.class);//값 가져오기

                lightTmp.setText(data);//textview에 값 설정하기
            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });



    }

}
