package com.example.smartpot;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    private ImageButton controlBtn;
    private ImageButton stateBtn;
    private ImageButton searchBtn;
    //private ImageButton autoBtn;
    private ImageButton bluetoothBtn;
    private String mngCheck="1";


    FirebaseDatabase database = FirebaseDatabase.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        initContent();
        initListener();
       // readdata();



        //DatabaseReference myRef11 = database.getReference("autoControl/autoWpercent");
        //myRef11.setValue("1");
        //DatabaseReference myRef12 = database.getReference("autoControl/autoWcontent");
        //myRef12.setValue("1");
        //DatabaseReference myRef13 = database.getReference("autoControl/lightTmp");
        //myRef13.setValue("1");
        //DatabaseReference myRef14 = database.getReference("potState/AHumi");
        //myRef14.setValue("1");
        //DatabaseReference myRef15 = database.getReference("potState/temp");
        //myRef15.setValue("1");
        //DatabaseReference myRef16 = database.getReference("potState/lux");
        //myRef16.setValue("1");
        //DatabaseReference myRef17 = database.getReference("potState/SHumi");
        //myRef17.setValue("1");
        //DatabaseReference myRef18 = database.getReference("potState/Wlevel");
        //myRef18.setValue("1");
        //DatabaseReference myRef19 = database.getReference("manualControl/plantName");
        //myRef19.setValue("1");
        //DatabaseReference myRef20 = database.getReference("manualControl/lampSwitch");
        //myRef20.setValue("1");
        //DatabaseReference myRef21 = database.getReference("ControlSwitch");
        //myRef21.setValue("1");
        //DatabaseReference myRef22 = database.getReference("manualControl/pumpSwitch");
        //myRef22.setValue("1");
        //DatabaseReference myRef23 = database.getReference("manualControl/waterContent");
        //myRef23.setValue("1");



        DatabaseReference myRef2 = database.getReference("ControlSwitch");
        myRef2.addValueEventListener(new ValueEventListener() {//습도

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                String data = dataSnapshot.getValue(String.class);//값 가져오기
                mngCheck=data;//관리스위치 정보저장
                //Toast.makeText(MainActivity.this, mngCheck, Toast.LENGTH_SHORT).show(); 테스트용
            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==101){
            if(resultCode==RESULT_OK){
            }
        }
        if(requestCode==103){
        }
        if(requestCode==104){
        }
   }

    private void initCatcher() {
        // 오류 발생시 프로그램을 강제로 종료시킵니다.
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(@NonNull Thread thread, @NonNull Throwable throwable) {
                System.exit(0);
            }
        });
    }

    private void initContent() {//xml하고 변수 연동
        controlBtn=findViewById(R.id.controlBtn);
        stateBtn=findViewById(R.id.stateBtn);
        searchBtn=findViewById(R.id.searchBtn);
        //autoBtn=findViewById(R.id.autoBtn);
        bluetoothBtn=findViewById(R.id.bluetoothBtn);

        //test=findViewById(R.id.test);
    }

    private void initListener(){//버튼 설정
        controlBtn.setOnClickListener(new View.OnClickListener(){//관리모드버튼
            public void onClick(View v){
                Intent intent=new Intent(getApplicationContext(), ControlActivity.class);
                intent.putExtra("ControlSwitch",mngCheck);
                startActivityForResult(intent, 101);
            }
        });

        stateBtn.setOnClickListener(new View.OnClickListener(){//식물인식버튼
            public void onClick(View v){
                Intent intent=new Intent(getApplicationContext(), StateActivity.class);
                startActivityForResult(intent, 102);
            }
        });

        searchBtn.setOnClickListener(new View.OnClickListener(){//수분공급버튼
            public void onClick(View v){
                Intent intent=new Intent(getApplicationContext(), SearchActivity.class);
                startActivityForResult(intent, 103);

            }
        });




        bluetoothBtn.setOnClickListener(new View.OnClickListener(){//블루투스
            public void onClick(View v){
                Intent intent=new Intent(getApplicationContext(), BluetoothActivity.class);
                startActivityForResult(intent, 105);
            }
        });
    }

   // public void readdata(){//
    //    FirebaseDatabase database = FirebaseDatabase.getInstance();
    //    DatabaseReference myRef = database.getReference("data/Date");
//
    //    myRef.addValueEventListener(new ValueEventListener() {

    //        @Override
     //       public void onDataChange(DataSnapshot dataSnapshot) {
     //           data = dataSnapshot.getValue(String.class);
      //          //test.setText(null);
                //test.setText(data);
      //      }
      //      @Override
      //      public void onCancelled(DatabaseError error) {
      //      }
     //   });
   // }


}


//<TextView
//            android:id="@+id/test"
//            android:layout_width="wrap_content"
//            android:layout_height="wrap_content"
//            android:layout_weight="1"/>