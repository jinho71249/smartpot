package com.example.smartpot;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.StringTokenizer;

public class RegActivity extends AppCompatActivity {

    private ImageButton stateBtn;
    private ImageButton selectBtn;

    private Spinner spinner;
    private String[] item;
    private String potnames;
    private int num;
    int i;


    FirebaseDatabase database = FirebaseDatabase.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.reglayout);
        initContent();
        initListener();



    }

    public void onStart() {
        super.onStart();

        final Db db=(Db)getApplicationContext();
        num=Integer.parseInt(db.getPotNum());
        potnames=db.getPotNames();
        item=new String[num];
        StringTokenizer tokens = new StringTokenizer(potnames, "#");
        i = 0;

        while (tokens.hasMoreTokens()) {
            item[i] = tokens.nextToken("#");
            i++;
        }


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                db.setSelectedPot(parent.getItemAtPosition(position).toString());//선택된 이름 전역변수에 저장
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {//아무것도 선택을 안할시
                Toast.makeText(getApplicationContext()
                        , "아무것도 선택되지 않음"
                        , Toast.LENGTH_SHORT).show();
            }
        });

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(RegActivity.this, android.R.layout.simple_spinner_item, item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);//스피너 적용
        spinner.setAdapter(adapter);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

    }

    private void initContent() {//xml하고 변수 연동
        stateBtn=findViewById(R.id.state);
        spinner=findViewById(R.id.spinner);
        selectBtn=findViewById(R.id.select);

    }

    private void initListener(){//버튼 설정

        selectBtn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent=new Intent(getApplicationContext(), StateActivity.class);
                startActivityForResult(intent, 110);
            }
        });

        stateBtn.setOnClickListener(new View.OnClickListener(){//블루투스
            public void onClick(View v){
                Intent intent=new Intent(getApplicationContext(), BluetoothActivity.class);
                startActivityForResult(intent, 111);
            }
        });


    }





}


