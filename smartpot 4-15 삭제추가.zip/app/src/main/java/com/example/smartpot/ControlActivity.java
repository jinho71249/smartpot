package com.example.smartpot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.StringTokenizer;

public class ControlActivity extends AppCompatActivity {
    private Switch lampSwitch;
    private Switch controlSwitch;
    private ImageButton supplyBtn;
    private ImageButton backBtn;
    private EditText waterContent;
    private String watercontent;
    private String lampCheck;
    private String controlCheck;
    private String potnames;
    private String []item;
    private int num;
    private int tmp;
    private String name;
    private String RC;

    FirebaseDatabase database = FirebaseDatabase.getInstance();

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.controllayout);
        final Db db=(Db)getApplication();
        num=db.getPotNum();
        potnames=db.getPotNames();
        item=new String[num];
        StringTokenizer tokens = new StringTokenizer(potnames, "#");
        int i = 0;

        while (tokens.hasMoreTokens()) {
            item[i] = tokens.nextToken("#");
            i++;
        }


        Intent intent=getIntent();
        tmp=intent.getIntExtra("potnum" ,0);
        RC=intent.getStringExtra("RC");
        if(RC.equals("0"))//0이면 manage로 온것
            name=item[tmp];
        else if(RC.equals("1"))//1이면 state에서 온것
            name=intent.getStringExtra("potname");
        else
        {
            Toast.makeText(ControlActivity.this, "오류.", Toast.LENGTH_SHORT).show();
            finish();
        }

        initContent();
        initListener();
    }

    private void initContent(){
        lampSwitch=findViewById(R.id.lampSwitch);
        controlSwitch =findViewById(R.id.controlSwitch);
        supplyBtn=findViewById(R.id.supplyBtn);
        backBtn=findViewById(R.id.backBtn);
        waterContent =findViewById(R.id.waterContent);
    }

    private void initListener(){

        DatabaseReference myRef2 = database.getReference(name+"/manualControl/lampSwitch");
        myRef2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                String data = dataSnapshot.getValue(String.class);//값 가져오기
                lampCheck =data;//관리스위치 정보저장

                if(lampCheck.equals("1"))
                    lampSwitch.setChecked(true);
                else
                    lampSwitch.setChecked(false);

            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        DatabaseReference myRef3 = database.getReference(name+"/ControlSwitch");
        myRef3.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                String data = dataSnapshot.getValue(String.class);//값 가져오기
                controlCheck =data;//관리스위치 정보저장

                if(controlCheck.equals("1"))
                    controlSwitch.setChecked(true);
                else
                    controlSwitch.setChecked(false);

            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        lampSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked){//스위치 버튼 동작
                DatabaseReference myRef2 = database.getReference(name+"/manualControl/lampSwitch");
                if(isChecked)
                    lampCheck = "1";
                else
                    lampCheck ="0";
                myRef2.setValue(lampCheck);
            }
        });

        controlSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked){//스위치 버튼 동작
                DatabaseReference myRef3 = database.getReference(name+"/ControlSwitch");
                if(isChecked) {
                    controlCheck = "1";
                    lampSwitch.setEnabled(false);
                    supplyBtn.setEnabled(false);
                }
                else {
                    controlCheck = "0";
                    lampSwitch.setEnabled(true);
                    supplyBtn.setEnabled(true);
                }
                myRef3.setValue(controlCheck);
            }
        });

        controlSwitch.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                if(controlCheck.equals("1")) {
                    Intent intent = new Intent(getApplicationContext(), AutoActivity.class);
                    intent.putExtra("name", name);
                    startActivityForResult(intent, 104);//test용
                }
                if(controlCheck.equals("0")) {
                    lampSwitch.setChecked(false);
                }
            }
        });









        supplyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                watercontent= waterContent.getText().toString();

                DatabaseReference myRef1 = database.getReference(name+"/manualControl/waterContent");
                myRef1.setValue(watercontent);

                Toast.makeText(ControlActivity.this, "수분공급량 전송.", Toast.LENGTH_SHORT).show();

            }
        });//수분공급버튼

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent out = new Intent();
                setResult(RESULT_CANCELED, out);
                finish();
            }
        });//돌아가기 버튼

    }

}


//DatabaseReference myRef1 = database.getReference("LightData/lightcheck"); //파이어베이스로 값 전달
//                myRef1.setValue(CHECK);
//                DatabaseReference myRef2 = database.getReference("LightData/lightHowlong");
//                myRef2.setValue(lGetTime);
//                DatabaseReference myRef3 = database.getReference("LightData/lightWhattime");
//                myRef3.setValue(lGetTimer);