package com.example.smartpot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ControlActivity extends AppCompatActivity {
    private Switch lightSwitch;
    private Switch mngSwitch;
    private ImageButton supplyBtn;
    private ImageButton backBtn;
    private EditText wSupVol;
    private String wsupVol;
    private String lightCheck;
    private String mngCheck;

    FirebaseDatabase database = FirebaseDatabase.getInstance();

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.controllayout);
        initContent();
        initListener();
    }

    private void initContent(){
        lightSwitch=findViewById(R.id.lightSwitch);
        mngSwitch=findViewById(R.id.mngSwitch);
        supplyBtn=findViewById(R.id.supplyBtn);
        backBtn=findViewById(R.id.backBtn);
        wSupVol=findViewById(R.id.wSupVol);
    }

    private void initListener(){

        DatabaseReference myRef2 = database.getReference("MngData/lightswitch");
        myRef2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                String data = dataSnapshot.getValue(String.class);//값 가져오기
                lightCheck=data;//관리스위치 정보저장

                if(lightCheck.equals("1"))
                    lightSwitch.setChecked(true);
                else
                    lightSwitch.setChecked(false);

            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        DatabaseReference myRef3 = database.getReference("MngData/mngswitch");
        myRef3.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {//파이어베이스 값이 변하면 동작하는 메소드
                String data = dataSnapshot.getValue(String.class);//값 가져오기
                mngCheck=data;//관리스위치 정보저장

                if(mngCheck.equals("1"))
                    mngSwitch.setChecked(true);
                else
                    mngSwitch.setChecked(false);

            }
            @Override
            public void onCancelled(DatabaseError error) {//에러났을때 동작하는 메소드
            }
        });

        lightSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked){//스위치 버튼 동작
                DatabaseReference myRef2 = database.getReference("MngData/lightswitch");
                if(isChecked)
                    lightCheck = "1";
                else
                    lightCheck="0";
                myRef2.setValue(lightCheck);
            }
        });

        mngSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked){//스위치 버튼 동작
                DatabaseReference myRef3 = database.getReference("MngData/mngswitch");
                if(isChecked) {
                    mngCheck = "1";
                }
                else {
                    mngCheck = "0";
                }
                myRef3.setValue(mngCheck);
            }
        });

        mngSwitch.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                if(mngCheck.equals("1")) {
                    Intent intent = new Intent(getApplicationContext(), AutoActivity.class);
                    startActivityForResult(intent, 104);//test용
                }
            }
        });





        supplyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                wsupVol=wSupVol.getText().toString();

                DatabaseReference myRef1 = database.getReference("WaterData/wSupVol");
                myRef1.setValue(wsupVol);

                Toast.makeText(ControlActivity.this, "수분공급량 전송.", Toast.LENGTH_SHORT).show();
                finish();
            }
        });//수분공급버튼

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent out = new Intent();
                setResult(RESULT_CANCELED, out);
                finish();
            }
        });//돌아가기 버튼

    }

}


//DatabaseReference myRef1 = database.getReference("LightData/lightcheck"); //파이어베이스로 값 전달
//                myRef1.setValue(CHECK);
//                DatabaseReference myRef2 = database.getReference("LightData/lightHowlong");
//                myRef2.setValue(lGetTime);
//                DatabaseReference myRef3 = database.getReference("LightData/lightWhattime");
//                myRef3.setValue(lGetTimer);