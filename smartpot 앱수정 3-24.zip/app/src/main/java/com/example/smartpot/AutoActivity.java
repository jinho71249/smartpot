package com.example.smartpot;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AutoActivity extends AppCompatActivity {
    private ImageButton saveBtn;
    private ImageButton backBtn;
    private EditText wLimitSup;
    private EditText wAutoSupVol;
    private EditText lightTmp;
    private String wlimitSup;
    private String wautoSupVol;
    private String lighttmp;

    FirebaseDatabase database = FirebaseDatabase.getInstance();


    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.autolayout);
        initContent();
        initListener();
    }

    private void initContent(){
        saveBtn=findViewById(R.id.saveBtn);
        backBtn=findViewById(R.id.backBtn);
        wLimitSup=findViewById(R.id.wLimitSup);
        wAutoSupVol=findViewById(R.id.wAutoSupVol);
        lightTmp=findViewById(R.id.lightTmp);

    }

    private void initListener(){
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent out = new Intent();
                setResult(RESULT_CANCELED, out);
                finish();
            }
        });

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wlimitSup=wLimitSup.getText().toString();
                wautoSupVol=wAutoSupVol.getText().toString();
                lighttmp=lightTmp.getText().toString();

                DatabaseReference myRef1 = database.getReference("AutoData/wLimitSup"); //파이어베이스로 값전달
                myRef1.setValue(wlimitSup);
                DatabaseReference myRef2 = database.getReference("AutoData/wAutoSupVol"); //파이어베이스로 값전달
                myRef2.setValue(wautoSupVol);
                DatabaseReference myRef3 = database.getReference("AutoData/lightTmp"); //파이어베이스로 값전달
                myRef3.setValue(lighttmp);

                //setResult(RESULT_OK, intent);
                finish();
            }
        });

    }

}
